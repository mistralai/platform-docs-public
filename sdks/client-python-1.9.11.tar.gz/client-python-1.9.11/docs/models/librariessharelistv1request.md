# LibrariesShareListV1Request


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `library_id`       | *str*              | :heavy_check_mark: | N/A                |