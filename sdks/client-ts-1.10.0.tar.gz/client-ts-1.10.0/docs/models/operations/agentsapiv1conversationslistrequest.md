# AgentsApiV1ConversationsListRequest

## Example Usage

```typescript
import { AgentsApiV1ConversationsListRequest } from "@mistralai/mistralai/models/operations";

let value: AgentsApiV1ConversationsListRequest = {};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `page`             | *number*           | :heavy_minus_sign: | N/A                |
| `pageSize`         | *number*           | :heavy_minus_sign: | N/A                |