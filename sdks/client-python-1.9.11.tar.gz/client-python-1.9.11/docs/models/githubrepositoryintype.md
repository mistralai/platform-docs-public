# GithubRepositoryInType


## Values

| Name     | Value    |
| -------- | -------- |
| `GITHUB` | github   |