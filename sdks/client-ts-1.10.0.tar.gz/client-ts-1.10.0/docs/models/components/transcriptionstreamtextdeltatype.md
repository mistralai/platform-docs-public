# TranscriptionStreamTextDeltaType

## Example Usage

```typescript
import { TranscriptionStreamTextDeltaType } from "@mistralai/mistralai/models/components";

let value: TranscriptionStreamTextDeltaType = "transcription.text.delta";
```

## Values

```typescript
"transcription.text.delta"
```