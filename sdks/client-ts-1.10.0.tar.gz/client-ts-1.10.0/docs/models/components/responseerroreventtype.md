# ResponseErrorEventType

## Example Usage

```typescript
import { ResponseErrorEventType } from "@mistralai/mistralai/models/components";

let value: ResponseErrorEventType = "conversation.response.error";
```

## Values

```typescript
"conversation.response.error"
```