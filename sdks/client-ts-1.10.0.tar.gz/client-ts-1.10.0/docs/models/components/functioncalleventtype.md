# FunctionCallEventType

## Example Usage

```typescript
import { FunctionCallEventType } from "@mistralai/mistralai/models/components";

let value: FunctionCallEventType = "function.call.delta";
```

## Values

```typescript
"function.call.delta"
```