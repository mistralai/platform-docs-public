# ImageURLChunkType

## Example Usage

```typescript
import { ImageURLChunkType } from "@mistralai/mistralai/models/components";

let value: ImageURLChunkType = "image_url";
```

## Values

```typescript
"image_url"
```