# WebSearchToolType

## Example Usage

```typescript
import { WebSearchToolType } from "@mistralai/mistralai/models/components";

let value: WebSearchToolType = "web_search";
```

## Values

```typescript
"web_search"
```