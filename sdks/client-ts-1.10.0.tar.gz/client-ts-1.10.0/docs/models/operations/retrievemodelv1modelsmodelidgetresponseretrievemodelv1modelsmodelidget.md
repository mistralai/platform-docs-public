# RetrieveModelV1ModelsModelIdGetResponseRetrieveModelV1ModelsModelIdGet

Successful Response


## Supported Types

### `components.FTModelCard`

```typescript
const value: components.FTModelCard = {
  id: "<id>",
  capabilities: {},
  job: "Global Interactions Strategist",
  root: "<value>",
};
```

### `components.BaseModelCard`

```typescript
const value: components.BaseModelCard = {
  id: "<id>",
  capabilities: {},
};
```

