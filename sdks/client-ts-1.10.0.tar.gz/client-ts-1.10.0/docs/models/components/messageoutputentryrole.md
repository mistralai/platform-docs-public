# MessageOutputEntryRole

## Example Usage

```typescript
import { MessageOutputEntryRole } from "@mistralai/mistralai/models/components";

let value: MessageOutputEntryRole = "assistant";
```

## Values

```typescript
"assistant"
```