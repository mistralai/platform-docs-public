# JobInRepositories


## Supported Types

### `components.GithubRepositoryIn`

```typescript
const value: components.GithubRepositoryIn = {
  name: "<value>",
  owner: "<value>",
  token: "<value>",
};
```

