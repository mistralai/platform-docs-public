# AssistantMessageRole


## Values

| Name        | Value       |
| ----------- | ----------- |
| `ASSISTANT` | assistant   |