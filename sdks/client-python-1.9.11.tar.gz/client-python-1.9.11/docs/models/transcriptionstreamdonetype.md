# TranscriptionStreamDoneType


## Values

| Name                 | Value                |
| -------------------- | -------------------- |
| `TRANSCRIPTION_DONE` | transcription.done   |