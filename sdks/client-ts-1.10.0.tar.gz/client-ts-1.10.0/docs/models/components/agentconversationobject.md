# AgentConversationObject

## Example Usage

```typescript
import { AgentConversationObject } from "@mistralai/mistralai/models/components";

let value: AgentConversationObject = "conversation";
```

## Values

```typescript
"conversation"
```