# ImageGenerationToolType

## Example Usage

```typescript
import { ImageGenerationToolType } from "@mistralai/mistralai/models/components";

let value: ImageGenerationToolType = "image_generation";
```

## Values

```typescript
"image_generation"
```