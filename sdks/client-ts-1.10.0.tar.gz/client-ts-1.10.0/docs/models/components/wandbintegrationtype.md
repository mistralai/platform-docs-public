# WandbIntegrationType

## Example Usage

```typescript
import { WandbIntegrationType } from "@mistralai/mistralai/models/components";

let value: WandbIntegrationType = "wandb";
```

## Values

```typescript
"wandb"
```