# GithubRepositoryOutType

## Example Usage

```typescript
import { GithubRepositoryOutType } from "@mistralai/mistralai/models/components";

let value: GithubRepositoryOutType = "github";
```

## Values

```typescript
"github"
```