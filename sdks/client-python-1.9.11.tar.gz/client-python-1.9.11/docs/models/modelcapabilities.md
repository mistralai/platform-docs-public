# ModelCapabilities


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `completion_chat`  | *Optional[bool]*   | :heavy_minus_sign: | N/A                |
| `completion_fim`   | *Optional[bool]*   | :heavy_minus_sign: | N/A                |
| `function_calling` | *Optional[bool]*   | :heavy_minus_sign: | N/A                |
| `fine_tuning`      | *Optional[bool]*   | :heavy_minus_sign: | N/A                |
| `vision`           | *Optional[bool]*   | :heavy_minus_sign: | N/A                |
| `classification`   | *Optional[bool]*   | :heavy_minus_sign: | N/A                |