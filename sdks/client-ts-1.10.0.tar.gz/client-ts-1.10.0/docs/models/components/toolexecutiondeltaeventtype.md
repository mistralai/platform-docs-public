# ToolExecutionDeltaEventType

## Example Usage

```typescript
import { ToolExecutionDeltaEventType } from "@mistralai/mistralai/models/components";

let value: ToolExecutionDeltaEventType = "tool.execution.delta";
```

## Values

```typescript
"tool.execution.delta"
```