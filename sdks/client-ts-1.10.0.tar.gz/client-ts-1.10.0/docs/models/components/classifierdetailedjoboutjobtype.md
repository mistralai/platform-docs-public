# ClassifierDetailedJobOutJobType

## Example Usage

```typescript
import { ClassifierDetailedJobOutJobType } from "@mistralai/mistralai/models/components";

let value: ClassifierDetailedJobOutJobType = "classifier";
```

## Values

```typescript
"classifier"
```