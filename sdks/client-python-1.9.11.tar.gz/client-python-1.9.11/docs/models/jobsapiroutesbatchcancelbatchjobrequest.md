# JobsAPIRoutesBatchCancelBatchJobRequest


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `job_id`           | *str*              | :heavy_check_mark: | N/A                |