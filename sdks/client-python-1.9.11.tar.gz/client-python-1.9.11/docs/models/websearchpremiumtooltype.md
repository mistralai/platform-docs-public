# WebSearchPremiumToolType


## Values

| Name                 | Value                |
| -------------------- | -------------------- |
| `WEB_SEARCH_PREMIUM` | web_search_premium   |