# AgentsAPIV1ConversationsAppendStreamRequest


## Fields

| Field                                                                                  | Type                                                                                   | Required                                                                               | Description                                                                            |
| -------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `conversation_id`                                                                      | *str*                                                                                  | :heavy_check_mark:                                                                     | ID of the conversation to which we append entries.                                     |
| `conversation_append_stream_request`                                                   | [models.ConversationAppendStreamRequest](../models/conversationappendstreamrequest.md) | :heavy_check_mark:                                                                     | N/A                                                                                    |