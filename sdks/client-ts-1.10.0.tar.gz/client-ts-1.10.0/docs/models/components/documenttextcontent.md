# DocumentTextContent

## Example Usage

```typescript
import { DocumentTextContent } from "@mistralai/mistralai/models/components";

let value: DocumentTextContent = {
  text: "<value>",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `text`             | *string*           | :heavy_check_mark: | N/A                |