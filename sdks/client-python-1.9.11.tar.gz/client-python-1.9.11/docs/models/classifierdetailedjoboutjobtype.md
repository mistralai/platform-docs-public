# ClassifierDetailedJobOutJobType


## Values

| Name         | Value        |
| ------------ | ------------ |
| `CLASSIFIER` | classifier   |