# ClassifierDetailedJobOutObject


## Values

| Name  | Value |
| ----- | ----- |
| `JOB` | job   |