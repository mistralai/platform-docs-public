# MessageInputEntryContent


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `List[models.MessageInputContentChunks]`

```python
value: List[models.MessageInputContentChunks] = /* values here */
```

