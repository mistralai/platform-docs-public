# ClassifierFTModelOutObject

## Example Usage

```typescript
import { ClassifierFTModelOutObject } from "@mistralai/mistralai/models/components";

let value: ClassifierFTModelOutObject = "model";
```

## Values

```typescript
"model"
```