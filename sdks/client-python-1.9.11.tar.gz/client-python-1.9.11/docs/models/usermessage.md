# UserMessage


## Fields

| Field                                                                  | Type                                                                   | Required                                                               | Description                                                            |
| ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| `content`                                                              | [Nullable[models.UserMessageContent]](../models/usermessagecontent.md) | :heavy_check_mark:                                                     | N/A                                                                    |
| `role`                                                                 | [Optional[models.UserMessageRole]](../models/usermessagerole.md)       | :heavy_minus_sign:                                                     | N/A                                                                    |