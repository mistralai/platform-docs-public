# ChatCompletionStreamRequestToolChoice


## Supported Types

### `components.ToolChoice`

```typescript
const value: components.ToolChoice = {
  function: {
    name: "<value>",
  },
};
```

### `components.ToolChoiceEnum`

```typescript
const value: components.ToolChoiceEnum = "required";
```

