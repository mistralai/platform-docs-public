# BatchJobsOut


## Fields

| Field                                                                  | Type                                                                   | Required                                                               | Description                                                            |
| ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| `data`                                                                 | List[[models.BatchJobOut](../models/batchjobout.md)]                   | :heavy_minus_sign:                                                     | N/A                                                                    |
| `object`                                                               | [Optional[models.BatchJobsOutObject]](../models/batchjobsoutobject.md) | :heavy_minus_sign:                                                     | N/A                                                                    |
| `total`                                                                | *int*                                                                  | :heavy_check_mark:                                                     | N/A                                                                    |