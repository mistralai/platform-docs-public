# ModelList


## Fields

| Field                                  | Type                                   | Required                               | Description                            |
| -------------------------------------- | -------------------------------------- | -------------------------------------- | -------------------------------------- |
| `object`                               | *Optional[str]*                        | :heavy_minus_sign:                     | N/A                                    |
| `data`                                 | List[[models.Data](../models/data.md)] | :heavy_minus_sign:                     | N/A                                    |