# ConversationEventsData


## Supported Types

### `models.AgentHandoffDoneEvent`

```python
value: models.AgentHandoffDoneEvent = /* values here */
```

### `models.AgentHandoffStartedEvent`

```python
value: models.AgentHandoffStartedEvent = /* values here */
```

### `models.ResponseDoneEvent`

```python
value: models.ResponseDoneEvent = /* values here */
```

### `models.ResponseErrorEvent`

```python
value: models.ResponseErrorEvent = /* values here */
```

### `models.ResponseStartedEvent`

```python
value: models.ResponseStartedEvent = /* values here */
```

### `models.FunctionCallEvent`

```python
value: models.FunctionCallEvent = /* values here */
```

### `models.MessageOutputEvent`

```python
value: models.MessageOutputEvent = /* values here */
```

### `models.ToolExecutionDeltaEvent`

```python
value: models.ToolExecutionDeltaEvent = /* values here */
```

### `models.ToolExecutionDoneEvent`

```python
value: models.ToolExecutionDoneEvent = /* values here */
```

### `models.ToolExecutionStartedEvent`

```python
value: models.ToolExecutionStartedEvent = /* values here */
```

