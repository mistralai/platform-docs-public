# JobsAPIRoutesFineTuningUpdateFineTunedModelResponse

OK


## Supported Types

### `models.ClassifierFTModelOut`

```python
value: models.ClassifierFTModelOut = /* values here */
```

### `models.CompletionFTModelOut`

```python
value: models.CompletionFTModelOut = /* values here */
```

