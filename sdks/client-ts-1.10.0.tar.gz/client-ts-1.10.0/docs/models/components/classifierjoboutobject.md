# ClassifierJobOutObject

The object type of the fine-tuning job.

## Example Usage

```typescript
import { ClassifierJobOutObject } from "@mistralai/mistralai/models/components";

let value: ClassifierJobOutObject = "job";
```

## Values

```typescript
"job"
```