# AgentHandoffStartedEventType

## Example Usage

```typescript
import { AgentHandoffStartedEventType } from "@mistralai/mistralai/models/components";

let value: AgentHandoffStartedEventType = "agent.handoff.started";
```

## Values

```typescript
"agent.handoff.started"
```