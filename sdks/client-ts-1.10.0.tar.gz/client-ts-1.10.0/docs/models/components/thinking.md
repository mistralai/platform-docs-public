# Thinking


## Supported Types

### `components.ReferenceChunk`

```typescript
const value: components.ReferenceChunk = {
  referenceIds: [],
};
```

### `components.TextChunk`

```typescript
const value: components.TextChunk = {
  text: "<value>",
};
```

