# ToolExecutionEntryType

## Example Usage

```typescript
import { ToolExecutionEntryType } from "@mistralai/mistralai/models/components";

let value: ToolExecutionEntryType = "tool.execution";
```

## Values

```typescript
"tool.execution"
```