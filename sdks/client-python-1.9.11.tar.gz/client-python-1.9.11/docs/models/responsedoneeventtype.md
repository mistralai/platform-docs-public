# ResponseDoneEventType


## Values

| Name                         | Value                        |
| ---------------------------- | ---------------------------- |
| `CONVERSATION_RESPONSE_DONE` | conversation.response.done   |