# ClassificationTargetResult


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `scores`           | Dict[str, *float*] | :heavy_check_mark: | N/A                |