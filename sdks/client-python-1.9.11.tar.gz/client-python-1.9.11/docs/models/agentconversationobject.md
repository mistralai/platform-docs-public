# AgentConversationObject


## Values

| Name           | Value          |
| -------------- | -------------- |
| `CONVERSATION` | conversation   |