# FunctionResultEntryType


## Values

| Name              | Value             |
| ----------------- | ----------------- |
| `FUNCTION_RESULT` | function.result   |