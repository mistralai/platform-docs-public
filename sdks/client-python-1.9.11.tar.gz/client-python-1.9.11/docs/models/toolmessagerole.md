# ToolMessageRole


## Values

| Name   | Value  |
| ------ | ------ |
| `TOOL` | tool   |