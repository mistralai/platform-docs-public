# ToolChoiceEnum

## Example Usage

```typescript
import { ToolChoiceEnum } from "@mistralai/mistralai/models/components";

let value: ToolChoiceEnum = "required";
```

## Values

```typescript
"auto" | "none" | "any" | "required"
```