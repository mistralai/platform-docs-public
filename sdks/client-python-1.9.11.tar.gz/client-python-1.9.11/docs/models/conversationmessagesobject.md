# ConversationMessagesObject


## Values

| Name                    | Value                   |
| ----------------------- | ----------------------- |
| `CONVERSATION_MESSAGES` | conversation.messages   |