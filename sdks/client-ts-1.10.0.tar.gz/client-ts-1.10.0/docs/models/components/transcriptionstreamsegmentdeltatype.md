# TranscriptionStreamSegmentDeltaType

## Example Usage

```typescript
import { TranscriptionStreamSegmentDeltaType } from "@mistralai/mistralai/models/components";

let value: TranscriptionStreamSegmentDeltaType = "transcription.segment";
```

## Values

```typescript
"transcription.segment"
```