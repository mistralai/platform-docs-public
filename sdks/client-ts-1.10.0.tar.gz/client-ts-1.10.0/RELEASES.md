

## 2024-08-07 14:12:46
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.356.0 (2.388.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.0] .
### Releases
- [NPM v1.0.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.0.0 - .

## 2024-08-07 17:09:34
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.356.0 (2.388.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.1] .
### Releases
- [NPM v1.0.1] https://www.npmjs.com/package/@mistralai/mistralai/v/1.0.1 - .

## 2024-08-08 18:05:34
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.357.4 (2.390.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.2] .
### Releases
- [NPM v1.0.2] https://www.npmjs.com/package/@mistralai/mistralai/v/1.0.2 - .

## 2024-08-20 08:43:27
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.376.0 (2.402.5) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.3] .
### Releases
- [NPM v1.0.3] https://www.npmjs.com/package/@mistralai/mistralai/v/1.0.3 - .

## 2024-08-23 13:33:36
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.378.0 (2.404.3) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.4] .
### Releases
- [NPM v1.0.4] https://www.npmjs.com/package/@mistralai/mistralai/v/1.0.4 - .

## 2024-09-18 14:34:12
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.399.2 (2.416.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.1.0] .
### Releases
- [NPM v1.1.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.1.0 - .

## 2024-11-07 16:53:54
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.434.2 (2.452.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.2.0] .
### Releases
- [NPM v1.2.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.2.0 - .

## 2024-11-07 20:58:48
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.434.4 (2.452.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.0] .
### Releases
- [NPM v1.3.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.3.0 - .

## 2024-11-12 18:04:57
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.438.1 (2.457.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.1] .
### Releases
- [NPM v1.3.1] https://www.npmjs.com/package/@mistralai/mistralai/v/1.3.1 - .

## 2024-11-15 18:37:02
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.438.1 (2.457.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.4] .
### Releases
- [NPM v1.3.4] https://www.npmjs.com/package/@mistralai/mistralai/v/1.3.4 - .

## 2024-12-04 09:42:29
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.451.1 (2.470.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.5] .
### Releases
- [NPM v1.3.5] https://www.npmjs.com/package/@mistralai/mistralai/v/1.3.5 - .

## 2025-01-06 10:25:54
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.462.2 (2.486.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.6] .
### Releases
- [NPM v1.3.6] https://www.npmjs.com/package/@mistralai/mistralai/v/1.3.6 - .

## 2025-01-21 10:40:40
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.469.11 (2.493.32) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.4.0] .
### Releases
- [NPM v1.4.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.4.0 - .

## 2025-01-27 14:54:13
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.476.2 (2.495.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.5.0] .
### Releases
- [NPM v1.5.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.5.0 - .

## 2025-03-06 16:38:32
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.477.0 (2.497.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.5.1] .
### Releases
- [NPM v1.5.1] https://www.npmjs.com/package/@mistralai/mistralai/v/1.5.1 - .

## 2025-03-14 09:44:35
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.5.2] .
### Releases
- [NPM v1.5.2] https://www.npmjs.com/package/@mistralai/mistralai/v/1.5.2 - .

## 2025-04-16 19:16:52
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.6.0] .
### Releases
- [NPM v1.6.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.6.0 - .

## 2025-05-22 15:00:21
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.6.1] .
### Releases
- [NPM v1.6.1] https://www.npmjs.com/package/@mistralai/mistralai/v/1.6.1 - .

## 2025-05-26 14:14:56
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.7.0] .
### Releases
- [NPM v1.7.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.7.0 - .

## 2025-05-28 14:41:45
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.7.1] .
### Releases
- [NPM v1.7.1] https://www.npmjs.com/package/@mistralai/mistralai/v/1.7.1 - .

## 2025-06-10 16:42:35
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.7.2] .
### Releases
- [NPM v1.7.2] https://www.npmjs.com/package/@mistralai/mistralai/v/1.7.2 - .

## 2025-07-01 07:55:31
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.7.3] .
### Releases
- [NPM v1.7.3] https://www.npmjs.com/package/@mistralai/mistralai/v/1.7.3 - .

## 2025-07-10 12:22:03
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.7.4] .
### Releases
- [NPM v1.7.4] https://www.npmjs.com/package/@mistralai/mistralai/v/1.7.4 - .

## 2025-07-23 19:12:02
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.7.5] .
### Releases
- [NPM v1.7.5] https://www.npmjs.com/package/@mistralai/mistralai/v/1.7.5 - .

## 2025-08-13 07:23:24
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.9.17] .
### Releases
- [NPM v1.9.17] https://www.npmjs.com/package/@mistralai/mistralai/v/1.9.17 - .

## 2025-08-20 08:28:36
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.9.18] .
### Releases
- [NPM v1.9.18] https://www.npmjs.com/package/@mistralai/mistralai/v/1.9.18 - .

## 2025-09-02 06:47:29
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.9.19] .
### Releases
- [NPM v1.9.19] https://www.npmjs.com/package/@mistralai/mistralai/v/1.9.19 - .

## 2025-09-02 13:40:15
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.606.10 (2.687.13) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.10.0] .
### Releases
- [NPM v1.10.0] https://www.npmjs.com/package/@mistralai/mistralai/v/1.10.0 - .