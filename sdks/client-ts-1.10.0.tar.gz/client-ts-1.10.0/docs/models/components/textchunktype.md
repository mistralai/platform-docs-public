# TextChunkType

## Example Usage

```typescript
import { TextChunkType } from "@mistralai/mistralai/models/components";

let value: TextChunkType = "text";
```

## Values

```typescript
"text"
```