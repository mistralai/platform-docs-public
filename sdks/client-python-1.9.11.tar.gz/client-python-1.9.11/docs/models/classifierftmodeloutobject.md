# ClassifierFTModelOutObject


## Values

| Name    | Value   |
| ------- | ------- |
| `MODEL` | model   |