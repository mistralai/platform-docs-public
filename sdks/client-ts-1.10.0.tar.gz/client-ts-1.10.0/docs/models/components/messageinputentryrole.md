# MessageInputEntryRole

## Example Usage

```typescript
import { MessageInputEntryRole } from "@mistralai/mistralai/models/components";

let value: MessageInputEntryRole = "assistant";
```

## Values

```typescript
"assistant" | "user"
```