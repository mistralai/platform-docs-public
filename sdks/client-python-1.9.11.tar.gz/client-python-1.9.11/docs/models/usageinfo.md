# UsageInfo


## Fields

| Field                   | Type                    | Required                | Description             |
| ----------------------- | ----------------------- | ----------------------- | ----------------------- |
| `prompt_tokens`         | *Optional[int]*         | :heavy_minus_sign:      | N/A                     |
| `completion_tokens`     | *Optional[int]*         | :heavy_minus_sign:      | N/A                     |
| `total_tokens`          | *Optional[int]*         | :heavy_minus_sign:      | N/A                     |
| `prompt_audio_seconds`  | *OptionalNullable[int]* | :heavy_minus_sign:      | N/A                     |
| `__pydantic_extra__`    | Dict[str, *Any*]        | :heavy_minus_sign:      | N/A                     |