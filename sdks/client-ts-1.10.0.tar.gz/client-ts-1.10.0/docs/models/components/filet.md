# FileT

## Example Usage

```typescript
import { FileT } from "@mistralai/mistralai/models/components";

// No examples available for this model
```

## Fields

| Field                        | Type                         | Required                     | Description                  |
| ---------------------------- | ---------------------------- | ---------------------------- | ---------------------------- |
| `fileName`                   | *string*                     | :heavy_check_mark:           | N/A                          |
| `content`                    | *ReadableStream<Uint8Array>* | :heavy_check_mark:           | N/A                          |