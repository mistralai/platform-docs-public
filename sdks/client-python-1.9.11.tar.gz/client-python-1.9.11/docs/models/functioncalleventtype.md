# FunctionCallEventType


## Values

| Name                  | Value                 |
| --------------------- | --------------------- |
| `FUNCTION_CALL_DELTA` | function.call.delta   |