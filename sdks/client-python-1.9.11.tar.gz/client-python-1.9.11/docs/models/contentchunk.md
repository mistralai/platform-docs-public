# ContentChunk


## Supported Types

### `models.ImageURLChunk`

```python
value: models.ImageURLChunk = /* values here */
```

### `models.DocumentURLChunk`

```python
value: models.DocumentURLChunk = /* values here */
```

### `models.TextChunk`

```python
value: models.TextChunk = /* values here */
```

### `models.ReferenceChunk`

```python
value: models.ReferenceChunk = /* values here */
```

### `models.FileChunk`

```python
value: models.FileChunk = /* values here */
```

### `models.ThinkChunk`

```python
value: models.ThinkChunk = /* values here */
```

### `models.AudioChunk`

```python
value: models.AudioChunk = /* values here */
```

