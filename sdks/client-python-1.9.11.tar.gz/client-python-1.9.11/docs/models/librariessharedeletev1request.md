# LibrariesShareDeleteV1Request


## Fields

| Field                                              | Type                                               | Required                                           | Description                                        |
| -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- |
| `library_id`                                       | *str*                                              | :heavy_check_mark:                                 | N/A                                                |
| `sharing_delete`                                   | [models.SharingDelete](../models/sharingdelete.md) | :heavy_check_mark:                                 | N/A                                                |