# LegacyJobMetadataOutObject


## Values

| Name           | Value          |
| -------------- | -------------- |
| `JOB_METADATA` | job.metadata   |