# FunctionCallEntryType

## Example Usage

```typescript
import { FunctionCallEntryType } from "@mistralai/mistralai/models/components";

let value: FunctionCallEntryType = "function.call";
```

## Values

```typescript
"function.call"
```