# JobsAPIRoutesFineTuningArchiveFineTunedModelRequest


## Fields

| Field                                         | Type                                          | Required                                      | Description                                   | Example                                       |
| --------------------------------------------- | --------------------------------------------- | --------------------------------------------- | --------------------------------------------- | --------------------------------------------- |
| `model_id`                                    | *str*                                         | :heavy_check_mark:                            | The ID of the model to archive.               | ft:open-mistral-7b:587a6b29:20240514:7e773925 |