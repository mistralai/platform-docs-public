# Tool


## Fields

| Field                                                | Type                                                 | Required                                             | Description                                          |
| ---------------------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------- |
| `type`                                               | [Optional[models.ToolTypes]](../models/tooltypes.md) | :heavy_minus_sign:                                   | N/A                                                  |
| `function`                                           | [models.Function](../models/function.md)             | :heavy_check_mark:                                   | N/A                                                  |