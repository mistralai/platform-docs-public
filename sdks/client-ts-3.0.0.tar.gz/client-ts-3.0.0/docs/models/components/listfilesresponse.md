# ListFilesResponse

## Example Usage

```typescript
import { ListFilesResponse } from "@mistralai/mistralai/models/components";

let value: ListFilesResponse = {
  data: [
    {
      id: "497f6eca-6276-4993-bfeb-53cbbbba6f09",
      object: "file",
      sizeBytes: 13000,
      createdAt: 1716963433,
      filename: "files_upload.jsonl",
      purpose: "ocr",
      sampleType: "batch_request",
      source: "upload",
    },
  ],
  object: "<value>",
};
```

## Fields

| Field                                                            | Type                                                             | Required                                                         | Description                                                      |
| ---------------------------------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------- |
| `data`                                                           | [components.FileSchema](../../models/components/fileschema.md)[] | :heavy_check_mark:                                               | N/A                                                              |
| `object`                                                         | *string*                                                         | :heavy_check_mark:                                               | N/A                                                              |
| `total`                                                          | *number*                                                         | :heavy_minus_sign:                                               | N/A                                                              |