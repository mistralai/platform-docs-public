# AgentHandoffEntryObject


## Values

| Name    | Value   |
| ------- | ------- |
| `ENTRY` | entry   |