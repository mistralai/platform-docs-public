# TranscriptionStreamTextDeltaType


## Values

| Name                       | Value                      |
| -------------------------- | -------------------------- |
| `TRANSCRIPTION_TEXT_DELTA` | transcription.text.delta   |