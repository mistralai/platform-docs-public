# ToolReferenceChunkType

## Example Usage

```typescript
import { ToolReferenceChunkType } from "@mistralai/mistralai/models/components";

let value: ToolReferenceChunkType = "tool_reference";
```

## Values

```typescript
"tool_reference"
```