# AgentHandoffEntryObject

## Example Usage

```typescript
import { AgentHandoffEntryObject } from "@mistralai/mistralai/models/components";

let value: AgentHandoffEntryObject = "entry";
```

## Values

```typescript
"entry"
```