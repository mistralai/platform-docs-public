# TextChunk


## Fields

| Field                                                        | Type                                                         | Required                                                     | Description                                                  |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| `text`                                                       | *str*                                                        | :heavy_check_mark:                                           | N/A                                                          |
| `type`                                                       | [Optional[models.TextChunkType]](../models/textchunktype.md) | :heavy_minus_sign:                                           | N/A                                                          |