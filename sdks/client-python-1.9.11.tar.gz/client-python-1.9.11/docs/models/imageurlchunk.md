# ImageURLChunk

{"type":"image_url","image_url":{"url":"data:image/png;base64,iVBORw0


## Fields

| Field                                                                | Type                                                                 | Required                                                             | Description                                                          |
| -------------------------------------------------------------------- | -------------------------------------------------------------------- | -------------------------------------------------------------------- | -------------------------------------------------------------------- |
| `image_url`                                                          | [models.ImageURLChunkImageURL](../models/imageurlchunkimageurl.md)   | :heavy_check_mark:                                                   | N/A                                                                  |
| `type`                                                               | [Optional[models.ImageURLChunkType]](../models/imageurlchunktype.md) | :heavy_minus_sign:                                                   | N/A                                                                  |