# Object


## Values

| Name    | Value   |
| ------- | ------- |
| `ENTRY` | entry   |