# ConversationResponseObject


## Values

| Name                    | Value                   |
| ----------------------- | ----------------------- |
| `CONVERSATION_RESPONSE` | conversation.response   |