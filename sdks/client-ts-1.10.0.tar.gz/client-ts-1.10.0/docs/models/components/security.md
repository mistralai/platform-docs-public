# Security

## Example Usage

```typescript
import { Security } from "@mistralai/mistralai/models/components";

let value: Security = {};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `apiKey`           | *string*           | :heavy_minus_sign: | N/A                |