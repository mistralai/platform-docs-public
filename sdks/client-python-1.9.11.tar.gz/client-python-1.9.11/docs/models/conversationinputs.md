# ConversationInputs


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `List[models.InputEntries]`

```python
value: List[models.InputEntries] = /* values here */
```

