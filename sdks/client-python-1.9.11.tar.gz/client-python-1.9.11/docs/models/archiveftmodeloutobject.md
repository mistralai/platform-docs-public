# ArchiveFTModelOutObject


## Values

| Name    | Value   |
| ------- | ------- |
| `MODEL` | model   |