# Source


## Values

| Name         | Value        |
| ------------ | ------------ |
| `UPLOAD`     | upload       |
| `REPOSITORY` | repository   |
| `MISTRAL`    | mistral      |