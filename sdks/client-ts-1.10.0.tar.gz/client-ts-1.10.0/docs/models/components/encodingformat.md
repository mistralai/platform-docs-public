# EncodingFormat

## Example Usage

```typescript
import { EncodingFormat } from "@mistralai/mistralai/models/components";

let value: EncodingFormat = "float";
```

## Values

```typescript
"float" | "base64"
```