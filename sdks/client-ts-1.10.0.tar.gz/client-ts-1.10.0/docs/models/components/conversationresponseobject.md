# ConversationResponseObject

## Example Usage

```typescript
import { ConversationResponseObject } from "@mistralai/mistralai/models/components";

let value: ConversationResponseObject = "conversation.response";
```

## Values

```typescript
"conversation.response"
```