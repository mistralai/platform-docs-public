# PaginationInfo


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `total_items`      | *int*              | :heavy_check_mark: | N/A                |
| `total_pages`      | *int*              | :heavy_check_mark: | N/A                |
| `current_page`     | *int*              | :heavy_check_mark: | N/A                |
| `page_size`        | *int*              | :heavy_check_mark: | N/A                |
| `has_more`         | *bool*             | :heavy_check_mark: | N/A                |