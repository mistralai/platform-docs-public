# UnarchiveFTModelOut


## Fields

| Field                                                                                | Type                                                                                 | Required                                                                             | Description                                                                          |
| ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ |
| `id`                                                                                 | *str*                                                                                | :heavy_check_mark:                                                                   | N/A                                                                                  |
| `object`                                                                             | [Optional[models.UnarchiveFTModelOutObject]](../models/unarchiveftmodeloutobject.md) | :heavy_minus_sign:                                                                   | N/A                                                                                  |
| `archived`                                                                           | *Optional[bool]*                                                                     | :heavy_minus_sign:                                                                   | N/A                                                                                  |