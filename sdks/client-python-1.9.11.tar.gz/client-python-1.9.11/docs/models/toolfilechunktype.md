# ToolFileChunkType


## Values

| Name        | Value       |
| ----------- | ----------- |
| `TOOL_FILE` | tool_file   |