# ModelType

## Example Usage

```typescript
import { ModelType } from "@mistralai/mistralai/models/components";

let value: ModelType = "completion";
```

## Values

```typescript
"completion"
```