# JobsApiRoutesFineTuningUpdateFineTunedModelResponse

OK


## Supported Types

### `components.ClassifierFTModelOut`

```typescript
const value: components.ClassifierFTModelOut = {
  id: "<id>",
  created: 111228,
  ownedBy: "<value>",
  workspaceId: "<id>",
  root: "<value>",
  rootVersion: "<value>",
  archived: true,
  capabilities: {},
  job: "b1e6e408-c7c5-4c7c-9c65-efca1702bf4b",
  classifierTargets: [],
};
```

### `components.CompletionFTModelOut`

```typescript
const value: components.CompletionFTModelOut = {
  id: "<id>",
  created: 787475,
  ownedBy: "<value>",
  workspaceId: "<id>",
  root: "<value>",
  rootVersion: "<value>",
  archived: false,
  capabilities: {},
  job: "0f147667-0d54-46fd-934d-6a88bd2ec484",
};
```

