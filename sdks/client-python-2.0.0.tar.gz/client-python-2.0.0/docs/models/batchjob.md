# BatchJob


## Fields

| Field                                                | Type                                                 | Required                                             | Description                                          |
| ---------------------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------- |
| `id`                                                 | *str*                                                | :heavy_check_mark:                                   | N/A                                                  |
| `object`                                             | *Optional[Literal["batch"]]*                         | :heavy_minus_sign:                                   | N/A                                                  |
| `input_files`                                        | List[*str*]                                          | :heavy_check_mark:                                   | N/A                                                  |
| `metadata`                                           | Dict[str, *Any*]                                     | :heavy_minus_sign:                                   | N/A                                                  |
| `endpoint`                                           | *str*                                                | :heavy_check_mark:                                   | N/A                                                  |
| `model`                                              | *OptionalNullable[str]*                              | :heavy_minus_sign:                                   | N/A                                                  |
| `agent_id`                                           | *OptionalNullable[str]*                              | :heavy_minus_sign:                                   | N/A                                                  |
| `output_file`                                        | *OptionalNullable[str]*                              | :heavy_minus_sign:                                   | N/A                                                  |
| `error_file`                                         | *OptionalNullable[str]*                              | :heavy_minus_sign:                                   | N/A                                                  |
| `errors`                                             | List[[models.BatchError](../models/batcherror.md)]   | :heavy_check_mark:                                   | N/A                                                  |
| `outputs`                                            | List[Dict[str, *Any*]]                               | :heavy_minus_sign:                                   | N/A                                                  |
| `status`                                             | [models.BatchJobStatus](../models/batchjobstatus.md) | :heavy_check_mark:                                   | N/A                                                  |
| `created_at`                                         | *int*                                                | :heavy_check_mark:                                   | N/A                                                  |
| `total_requests`                                     | *int*                                                | :heavy_check_mark:                                   | N/A                                                  |
| `completed_requests`                                 | *int*                                                | :heavy_check_mark:                                   | N/A                                                  |
| `succeeded_requests`                                 | *int*                                                | :heavy_check_mark:                                   | N/A                                                  |
| `failed_requests`                                    | *int*                                                | :heavy_check_mark:                                   | N/A                                                  |
| `started_at`                                         | *OptionalNullable[int]*                              | :heavy_minus_sign:                                   | N/A                                                  |
| `completed_at`                                       | *OptionalNullable[int]*                              | :heavy_minus_sign:                                   | N/A                                                  |