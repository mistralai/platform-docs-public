# WandbIntegrationType


## Values

| Name    | Value   |
| ------- | ------- |
| `WANDB` | wandb   |