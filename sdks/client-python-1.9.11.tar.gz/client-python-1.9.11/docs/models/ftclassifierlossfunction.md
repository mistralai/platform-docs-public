# FTClassifierLossFunction


## Values

| Name           | Value          |
| -------------- | -------------- |
| `SINGLE_CLASS` | single_class   |
| `MULTI_CLASS`  | multi_class    |