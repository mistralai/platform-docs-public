# TranscriptionStreamEventTypes


## Values

| Name                       | Value                      |
| -------------------------- | -------------------------- |
| `TRANSCRIPTION_LANGUAGE`   | transcription.language     |
| `TRANSCRIPTION_SEGMENT`    | transcription.segment      |
| `TRANSCRIPTION_TEXT_DELTA` | transcription.text.delta   |
| `TRANSCRIPTION_DONE`       | transcription.done         |