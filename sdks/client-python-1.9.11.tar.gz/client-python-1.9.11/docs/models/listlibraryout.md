# ListLibraryOut


## Fields

| Field                                              | Type                                               | Required                                           | Description                                        |
| -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- |
| `data`                                             | List[[models.LibraryOut](../models/libraryout.md)] | :heavy_check_mark:                                 | N/A                                                |