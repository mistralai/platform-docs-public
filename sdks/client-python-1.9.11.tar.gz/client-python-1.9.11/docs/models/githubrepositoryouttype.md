# GithubRepositoryOutType


## Values

| Name     | Value    |
| -------- | -------- |
| `GITHUB` | github   |