# CodeInterpreterToolType

## Example Usage

```typescript
import { CodeInterpreterToolType } from "@mistralai/mistralai/models/components";

let value: CodeInterpreterToolType = "code_interpreter";
```

## Values

```typescript
"code_interpreter"
```