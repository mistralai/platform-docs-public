# MessageOutputEntryRole


## Values

| Name        | Value       |
| ----------- | ----------- |
| `ASSISTANT` | assistant   |