# WebSearchTool

## Example Usage

```typescript
import { WebSearchTool } from "@mistralai/mistralai/models/components";

let value: WebSearchTool = {};
```

## Fields

| Field                                                                        | Type                                                                         | Required                                                                     | Description                                                                  |
| ---------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `type`                                                                       | [components.WebSearchToolType](../../models/components/websearchtooltype.md) | :heavy_minus_sign:                                                           | N/A                                                                          |