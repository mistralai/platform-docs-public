# MessageOutputEventType

## Example Usage

```typescript
import { MessageOutputEventType } from "@mistralai/mistralai/models/components";

let value: MessageOutputEventType = "message.output.delta";
```

## Values

```typescript
"message.output.delta"
```