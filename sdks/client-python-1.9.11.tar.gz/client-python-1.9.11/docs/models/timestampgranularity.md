# TimestampGranularity


## Values

| Name      | Value     |
| --------- | --------- |
| `SEGMENT` | segment   |