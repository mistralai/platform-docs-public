# Messages


## Supported Types

### `models.AssistantMessage`

```python
value: models.AssistantMessage = /* values here */
```

### `models.SystemMessage`

```python
value: models.SystemMessage = /* values here */
```

### `models.ToolMessage`

```python
value: models.ToolMessage = /* values here */
```

### `models.UserMessage`

```python
value: models.UserMessage = /* values here */
```

