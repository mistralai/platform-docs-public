# ClassifierFTModelOutModelType


## Values

| Name         | Value        |
| ------------ | ------------ |
| `CLASSIFIER` | classifier   |