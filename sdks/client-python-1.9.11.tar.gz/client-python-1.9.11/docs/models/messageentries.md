# MessageEntries


## Supported Types

### `models.MessageInputEntry`

```python
value: models.MessageInputEntry = /* values here */
```

### `models.MessageOutputEntry`

```python
value: models.MessageOutputEntry = /* values here */
```

