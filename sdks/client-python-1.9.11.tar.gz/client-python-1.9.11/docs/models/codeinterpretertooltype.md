# CodeInterpreterToolType


## Values

| Name               | Value              |
| ------------------ | ------------------ |
| `CODE_INTERPRETER` | code_interpreter   |