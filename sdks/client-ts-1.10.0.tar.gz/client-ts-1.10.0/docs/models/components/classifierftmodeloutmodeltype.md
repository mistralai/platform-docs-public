# ClassifierFTModelOutModelType

## Example Usage

```typescript
import { ClassifierFTModelOutModelType } from "@mistralai/mistralai/models/components";

let value: ClassifierFTModelOutModelType = "classifier";
```

## Values

```typescript
"classifier"
```