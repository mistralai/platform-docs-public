# Response1


## Supported Types

### `models.ClassifierJobOut`

```python
value: models.ClassifierJobOut = /* values here */
```

### `models.CompletionJobOut`

```python
value: models.CompletionJobOut = /* values here */
```

