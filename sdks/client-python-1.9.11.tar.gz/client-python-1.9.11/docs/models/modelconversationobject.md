# ModelConversationObject


## Values

| Name           | Value          |
| -------------- | -------------- |
| `CONVERSATION` | conversation   |