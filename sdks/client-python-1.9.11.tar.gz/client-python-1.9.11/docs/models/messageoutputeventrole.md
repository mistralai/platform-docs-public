# MessageOutputEventRole


## Values

| Name        | Value       |
| ----------- | ----------- |
| `ASSISTANT` | assistant   |