# ListFilesOut


## Fields

| Field                                              | Type                                               | Required                                           | Description                                        |
| -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- |
| `data`                                             | List[[models.FileSchema](../models/fileschema.md)] | :heavy_check_mark:                                 | N/A                                                |
| `object`                                           | *str*                                              | :heavy_check_mark:                                 | N/A                                                |
| `total`                                            | *int*                                              | :heavy_check_mark:                                 | N/A                                                |