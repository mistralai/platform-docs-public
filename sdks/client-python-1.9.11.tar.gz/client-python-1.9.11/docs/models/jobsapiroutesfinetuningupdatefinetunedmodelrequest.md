# JobsAPIRoutesFineTuningUpdateFineTunedModelRequest


## Fields

| Field                                                  | Type                                                   | Required                                               | Description                                            | Example                                                |
| ------------------------------------------------------ | ------------------------------------------------------ | ------------------------------------------------------ | ------------------------------------------------------ | ------------------------------------------------------ |
| `model_id`                                             | *str*                                                  | :heavy_check_mark:                                     | The ID of the model to update.                         | ft:open-mistral-7b:587a6b29:20240514:7e773925          |
| `update_ft_model_in`                                   | [models.UpdateFTModelIn](../models/updateftmodelin.md) | :heavy_check_mark:                                     | N/A                                                    |                                                        |