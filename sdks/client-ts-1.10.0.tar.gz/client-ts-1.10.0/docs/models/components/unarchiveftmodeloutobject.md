# UnarchiveFTModelOutObject

## Example Usage

```typescript
import { UnarchiveFTModelOutObject } from "@mistralai/mistralai/models/components";

let value: UnarchiveFTModelOutObject = "model";
```

## Values

```typescript
"model"
```