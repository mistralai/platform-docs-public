# Thinking


## Supported Types

### `models.ReferenceChunk`

```python
value: models.ReferenceChunk = /* values here */
```

### `models.TextChunk`

```python
value: models.TextChunk = /* values here */
```

