# ChatClassificationRequest


## Fields

| Field                                | Type                                 | Required                             | Description                          |
| ------------------------------------ | ------------------------------------ | ------------------------------------ | ------------------------------------ |
| `model`                              | *str*                                | :heavy_check_mark:                   | N/A                                  |
| `inputs`                             | [models.Inputs](../models/inputs.md) | :heavy_check_mark:                   | Chat to classify                     |