# MessageOutputEntryObject


## Values

| Name    | Value   |
| ------- | ------- |
| `ENTRY` | entry   |