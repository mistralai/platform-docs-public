# FunctionResultEntryType

## Example Usage

```typescript
import { FunctionResultEntryType } from "@mistralai/mistralai/models/components";

let value: FunctionResultEntryType = "function.result";
```

## Values

```typescript
"function.result"
```