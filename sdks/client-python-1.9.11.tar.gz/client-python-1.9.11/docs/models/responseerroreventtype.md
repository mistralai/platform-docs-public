# ResponseErrorEventType


## Values

| Name                          | Value                         |
| ----------------------------- | ----------------------------- |
| `CONVERSATION_RESPONSE_ERROR` | conversation.response.error   |