# MessageOutputEntryContent


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `List[models.MessageOutputContentChunks]`

```python
value: List[models.MessageOutputContentChunks] = /* values here */
```

