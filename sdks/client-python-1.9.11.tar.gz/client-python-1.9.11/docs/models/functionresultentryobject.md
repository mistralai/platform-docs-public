# FunctionResultEntryObject


## Values

| Name    | Value   |
| ------- | ------- |
| `ENTRY` | entry   |