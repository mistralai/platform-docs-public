# JobsApiRoutesBatchCancelBatchJobRequest

## Example Usage

```typescript
import { JobsApiRoutesBatchCancelBatchJobRequest } from "@mistralai/mistralai/models/operations";

let value: JobsApiRoutesBatchCancelBatchJobRequest = {
  jobId: "a7511a85-c720-4fc8-9028-9146225c5f34",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `jobId`            | *string*           | :heavy_check_mark: | N/A                |