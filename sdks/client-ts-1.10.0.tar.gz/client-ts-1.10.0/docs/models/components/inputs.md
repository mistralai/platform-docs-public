# Inputs

Chat to classify


## Supported Types

### `components.InstructRequestInputs`

```typescript
const value: components.InstructRequestInputs = {
  messages: [],
};
```

### `components.InstructRequest[]`

```typescript
const value: components.InstructRequest[] = [];
```

