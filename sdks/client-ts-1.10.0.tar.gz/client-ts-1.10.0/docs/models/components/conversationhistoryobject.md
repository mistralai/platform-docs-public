# ConversationHistoryObject

## Example Usage

```typescript
import { ConversationHistoryObject } from "@mistralai/mistralai/models/components";

let value: ConversationHistoryObject = "conversation.history";
```

## Values

```typescript
"conversation.history"
```