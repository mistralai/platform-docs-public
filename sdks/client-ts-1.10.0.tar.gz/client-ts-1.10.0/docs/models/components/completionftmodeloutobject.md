# CompletionFTModelOutObject

## Example Usage

```typescript
import { CompletionFTModelOutObject } from "@mistralai/mistralai/models/components";

let value: CompletionFTModelOutObject = "model";
```

## Values

```typescript
"model"
```