# CompletionResponseStreamChoiceFinishReason


## Values

| Name         | Value        |
| ------------ | ------------ |
| `STOP`       | stop         |
| `LENGTH`     | length       |
| `ERROR`      | error        |
| `TOOL_CALLS` | tool_calls   |