# JobsAPIRoutesFineTuningCancelFineTuningJobRequest


## Fields

| Field                        | Type                         | Required                     | Description                  |
| ---------------------------- | ---------------------------- | ---------------------------- | ---------------------------- |
| `job_id`                     | *str*                        | :heavy_check_mark:           | The ID of the job to cancel. |