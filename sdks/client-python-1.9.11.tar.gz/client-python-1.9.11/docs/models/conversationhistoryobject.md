# ConversationHistoryObject


## Values

| Name                   | Value                  |
| ---------------------- | ---------------------- |
| `CONVERSATION_HISTORY` | conversation.history   |