# ChatModerationRequestInputs

Chat to classify


## Supported Types

### `List[models.One]`

```python
value: List[models.One] = /* values here */
```

### `List[List[models.Two]]`

```python
value: List[List[models.Two]] = /* values here */
```

