# MessageInputEntryType

## Example Usage

```typescript
import { MessageInputEntryType } from "@mistralai/mistralai/models/components";

let value: MessageInputEntryType = "message.input";
```

## Values

```typescript
"message.input"
```