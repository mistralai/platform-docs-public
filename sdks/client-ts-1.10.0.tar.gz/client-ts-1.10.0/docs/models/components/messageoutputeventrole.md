# MessageOutputEventRole

## Example Usage

```typescript
import { MessageOutputEventRole } from "@mistralai/mistralai/models/components";

let value: MessageOutputEventRole = "assistant";
```

## Values

```typescript
"assistant"
```