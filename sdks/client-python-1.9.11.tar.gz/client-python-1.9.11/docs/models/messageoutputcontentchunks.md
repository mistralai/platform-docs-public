# MessageOutputContentChunks


## Supported Types

### `models.TextChunk`

```python
value: models.TextChunk = /* values here */
```

### `models.ImageURLChunk`

```python
value: models.ImageURLChunk = /* values here */
```

### `models.ToolFileChunk`

```python
value: models.ToolFileChunk = /* values here */
```

### `models.DocumentURLChunk`

```python
value: models.DocumentURLChunk = /* values here */
```

### `models.ThinkChunk`

```python
value: models.ThinkChunk = /* values here */
```

### `models.ToolReferenceChunk`

```python
value: models.ToolReferenceChunk = /* values here */
```

