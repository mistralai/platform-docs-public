# FunctionCallEntryObject


## Values

| Name    | Value   |
| ------- | ------- |
| `ENTRY` | entry   |