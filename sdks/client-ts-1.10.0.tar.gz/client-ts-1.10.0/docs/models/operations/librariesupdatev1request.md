# LibrariesUpdateV1Request

## Example Usage

```typescript
import { LibrariesUpdateV1Request } from "@mistralai/mistralai/models/operations";

let value: LibrariesUpdateV1Request = {
  libraryId: "e52f793f-78fd-4e00-a99a-417c791644e6",
  libraryInUpdate: {},
};
```

## Fields

| Field                                                                    | Type                                                                     | Required                                                                 | Description                                                              |
| ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ |
| `libraryId`                                                              | *string*                                                                 | :heavy_check_mark:                                                       | N/A                                                                      |
| `libraryInUpdate`                                                        | [components.LibraryInUpdate](../../models/components/libraryinupdate.md) | :heavy_check_mark:                                                       | N/A                                                                      |