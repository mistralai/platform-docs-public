# WebSearchPremiumToolType

## Example Usage

```typescript
import { WebSearchPremiumToolType } from "@mistralai/mistralai/models/components";

let value: WebSearchPremiumToolType = "web_search_premium";
```

## Values

```typescript
"web_search_premium"
```