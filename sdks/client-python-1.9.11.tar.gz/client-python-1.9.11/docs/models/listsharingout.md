# ListSharingOut


## Fields

| Field                                              | Type                                               | Required                                           | Description                                        |
| -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- |
| `data`                                             | List[[models.SharingOut](../models/sharingout.md)] | :heavy_check_mark:                                 | N/A                                                |