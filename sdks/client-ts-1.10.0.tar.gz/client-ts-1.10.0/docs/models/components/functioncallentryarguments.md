# FunctionCallEntryArguments


## Supported Types

### `{ [k: string]: any }`

```typescript
const value: { [k: string]: any } = {
  "key": "<value>",
  "key1": "<value>",
  "key2": "<value>",
};
```

### `string`

```typescript
const value: string = "<value>";
```

