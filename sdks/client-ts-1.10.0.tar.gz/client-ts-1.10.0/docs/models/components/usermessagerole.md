# UserMessageRole

## Example Usage

```typescript
import { UserMessageRole } from "@mistralai/mistralai/models/components";

let value: UserMessageRole = "user";
```

## Values

```typescript
"user"
```