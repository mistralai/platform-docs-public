# MessageInputEntryRole


## Values

| Name        | Value       |
| ----------- | ----------- |
| `ASSISTANT` | assistant   |
| `USER`      | user        |