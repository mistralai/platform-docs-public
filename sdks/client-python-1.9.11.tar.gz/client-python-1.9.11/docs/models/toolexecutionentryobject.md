# ToolExecutionEntryObject


## Values

| Name    | Value   |
| ------- | ------- |
| `ENTRY` | entry   |