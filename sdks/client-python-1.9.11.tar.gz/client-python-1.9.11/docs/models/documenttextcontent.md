# DocumentTextContent


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `text`             | *str*              | :heavy_check_mark: | N/A                |