# FunctionToolType

## Example Usage

```typescript
import { FunctionToolType } from "@mistralai/mistralai/models/components";

let value: FunctionToolType = "function";
```

## Values

```typescript
"function"
```