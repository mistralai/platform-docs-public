# ReferenceChunkType

## Example Usage

```typescript
import { ReferenceChunkType } from "@mistralai/mistralai/models/components";

let value: ReferenceChunkType = "reference";
```

## Values

```typescript
"reference"
```