

## 2024-08-07 12:27:19
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.356.0 (2.388.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.0] packages/mistralai-azure
### Releases
- [NPM v1.0.0] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.0.0 - packages/mistralai-azure

## 2024-08-08 18:05:55
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.357.4 (2.390.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.2] packages/mistralai-azure
### Releases
- [NPM v1.0.2] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.0.2 - packages/mistralai-azure

## 2024-08-20 08:43:15
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.376.0 (2.402.5) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.3] packages/mistralai-azure
### Releases
- [NPM v1.0.3] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.0.3 - packages/mistralai-azure

## 2024-08-23 12:00:05
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.378.0 (2.404.3) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.0.4] packages/mistralai-azure
### Releases
- [NPM v1.0.4] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.0.4 - packages/mistralai-azure

## 2024-09-19 11:35:36
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.399.3 (2.420.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.1.0] packages/mistralai-azure
### Releases
- [NPM v1.1.0] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.1.0 - packages/mistralai-azure

## 2024-11-08 13:01:44
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.434.7 (2.452.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.0] packages/mistralai-azure
### Releases
- [NPM v1.3.0] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.3.0 - packages/mistralai-azure

## 2024-11-12 18:05:05
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.438.1 (2.457.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.1] packages/mistralai-azure
### Releases
- [NPM v1.3.1] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.3.1 - packages/mistralai-azure

## 2024-11-15 18:36:42
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.438.1 (2.457.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.4] packages/mistralai-azure
### Releases
- [NPM v1.3.4] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.3.4 - packages/mistralai-azure

## 2024-12-04 09:27:57
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.451.1 (2.470.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.5] packages/mistralai-azure
### Releases
- [NPM v1.3.5] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.3.5 - packages/mistralai-azure

## 2025-01-06 10:25:32
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.462.2 (2.486.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.3.6] packages/mistralai-azure
### Releases
- [NPM v1.3.6] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.3.6 - packages/mistralai-azure

## 2025-01-21 10:40:54
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.469.11 (2.493.32) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.4.0] packages/mistralai-azure
### Releases
- [NPM v1.4.0] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.4.0 - packages/mistralai-azure

## 2025-03-20 14:22:44
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.5.0] packages/mistralai-azure
### Releases
- [NPM v1.5.0] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.5.0 - packages/mistralai-azure

## 2025-08-25 14:52:23
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [typescript v1.6.0] packages/mistralai-azure
### Releases
- [NPM v1.6.0] https://www.npmjs.com/package/@mistralai/mistralai-azure/v/1.6.0 - packages/mistralai-azure