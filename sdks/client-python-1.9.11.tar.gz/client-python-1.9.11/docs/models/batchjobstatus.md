# BatchJobStatus


## Values

| Name                     | Value                    |
| ------------------------ | ------------------------ |
| `QUEUED`                 | QUEUED                   |
| `RUNNING`                | RUNNING                  |
| `SUCCESS`                | SUCCESS                  |
| `FAILED`                 | FAILED                   |
| `TIMEOUT_EXCEEDED`       | TIMEOUT_EXCEEDED         |
| `CANCELLATION_REQUESTED` | CANCELLATION_REQUESTED   |
| `CANCELLED`              | CANCELLED                |