# BatchJobsOutObject

## Example Usage

```typescript
import { BatchJobsOutObject } from "@mistralai/mistralai/models/components";

let value: BatchJobsOutObject = "list";
```

## Values

```typescript
"list"
```