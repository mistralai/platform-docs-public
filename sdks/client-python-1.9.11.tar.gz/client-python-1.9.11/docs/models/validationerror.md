# ValidationError


## Fields

| Field                                | Type                                 | Required                             | Description                          |
| ------------------------------------ | ------------------------------------ | ------------------------------------ | ------------------------------------ |
| `loc`                                | List[[models.Loc](../models/loc.md)] | :heavy_check_mark:                   | N/A                                  |
| `msg`                                | *str*                                | :heavy_check_mark:                   | N/A                                  |
| `type`                               | *str*                                | :heavy_check_mark:                   | N/A                                  |