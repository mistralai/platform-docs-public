# GetDatasetRecordsV1ObservabilityDatasetsDatasetIDRecordsGetRequest


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `dataset_id`       | *str*              | :heavy_check_mark: | N/A                |
| `page_size`        | *Optional[int]*    | :heavy_minus_sign: | N/A                |
| `page`             | *Optional[int]*    | :heavy_minus_sign: | N/A                |