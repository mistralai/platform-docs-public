# ResponseStartedEventType


## Values

| Name                            | Value                           |
| ------------------------------- | ------------------------------- |
| `CONVERSATION_RESPONSE_STARTED` | conversation.response.started   |