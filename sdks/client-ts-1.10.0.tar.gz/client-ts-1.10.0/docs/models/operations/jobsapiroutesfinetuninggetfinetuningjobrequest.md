# JobsApiRoutesFineTuningGetFineTuningJobRequest

## Example Usage

```typescript
import { JobsApiRoutesFineTuningGetFineTuningJobRequest } from "@mistralai/mistralai/models/operations";

let value: JobsApiRoutesFineTuningGetFineTuningJobRequest = {
  jobId: "b9e861b8-540e-4c8d-b022-6665a4d86b5e",
};
```

## Fields

| Field                         | Type                          | Required                      | Description                   |
| ----------------------------- | ----------------------------- | ----------------------------- | ----------------------------- |
| `jobId`                       | *string*                      | :heavy_check_mark:            | The ID of the job to analyse. |