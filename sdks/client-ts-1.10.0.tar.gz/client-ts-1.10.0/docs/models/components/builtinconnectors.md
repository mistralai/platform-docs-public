# BuiltInConnectors

## Example Usage

```typescript
import { BuiltInConnectors } from "@mistralai/mistralai/models/components";

let value: BuiltInConnectors = "document_library";
```

## Values

```typescript
"web_search" | "web_search_premium" | "code_interpreter" | "image_generation" | "document_library"
```