# DocumentLibraryToolType

## Example Usage

```typescript
import { DocumentLibraryToolType } from "@mistralai/mistralai/models/components";

let value: DocumentLibraryToolType = "document_library";
```

## Values

```typescript
"document_library"
```