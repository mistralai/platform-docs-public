# LibrariesDocumentsReprocessV1Request

## Example Usage

```typescript
import { LibrariesDocumentsReprocessV1Request } from "@mistralai/mistralai/models/operations";

let value: LibrariesDocumentsReprocessV1Request = {
  libraryId: "c8741ace-7d56-44cc-810e-666c3e5e2c4a",
  documentId: "ac82a047-2958-4362-97f2-db506f4e09f5",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `libraryId`        | *string*           | :heavy_check_mark: | N/A                |
| `documentId`       | *string*           | :heavy_check_mark: | N/A                |