# AudioChunkType


## Values

| Name          | Value         |
| ------------- | ------------- |
| `INPUT_AUDIO` | input_audio   |