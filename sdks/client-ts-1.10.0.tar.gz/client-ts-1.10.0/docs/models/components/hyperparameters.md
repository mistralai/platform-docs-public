# Hyperparameters


## Supported Types

### `components.CompletionTrainingParametersIn`

```typescript
const value: components.CompletionTrainingParametersIn = {};
```

### `components.ClassifierTrainingParametersIn`

```typescript
const value: components.ClassifierTrainingParametersIn = {};
```

