# UserMessageRole


## Values

| Name   | Value  |
| ------ | ------ |
| `USER` | user   |