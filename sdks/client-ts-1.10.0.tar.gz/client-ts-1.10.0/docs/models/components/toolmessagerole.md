# ToolMessageRole

## Example Usage

```typescript
import { ToolMessageRole } from "@mistralai/mistralai/models/components";

let value: ToolMessageRole = "tool";
```

## Values

```typescript
"tool"
```