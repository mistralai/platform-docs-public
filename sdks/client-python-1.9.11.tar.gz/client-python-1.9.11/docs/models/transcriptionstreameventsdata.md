# TranscriptionStreamEventsData


## Supported Types

### `models.TranscriptionStreamDone`

```python
value: models.TranscriptionStreamDone = /* values here */
```

### `models.TranscriptionStreamLanguage`

```python
value: models.TranscriptionStreamLanguage = /* values here */
```

### `models.TranscriptionStreamSegmentDelta`

```python
value: models.TranscriptionStreamSegmentDelta = /* values here */
```

### `models.TranscriptionStreamTextDelta`

```python
value: models.TranscriptionStreamTextDelta = /* values here */
```

