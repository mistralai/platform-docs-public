# SystemMessageContentChunks


## Supported Types

### `models.TextChunk`

```python
value: models.TextChunk = /* values here */
```

### `models.ThinkChunk`

```python
value: models.ThinkChunk = /* values here */
```

