# ConversationAppendRequestHandoffExecution

## Example Usage

```typescript
import { ConversationAppendRequestHandoffExecution } from "@mistralai/mistralai/models/components";

let value: ConversationAppendRequestHandoffExecution = "server";
```

## Values

```typescript
"client" | "server"
```