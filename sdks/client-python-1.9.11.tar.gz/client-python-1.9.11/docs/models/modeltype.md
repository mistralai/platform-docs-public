# ModelType


## Values

| Name         | Value        |
| ------------ | ------------ |
| `COMPLETION` | completion   |