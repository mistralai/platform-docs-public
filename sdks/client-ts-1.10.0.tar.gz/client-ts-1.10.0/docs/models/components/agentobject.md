# AgentObject

## Example Usage

```typescript
import { AgentObject } from "@mistralai/mistralai/models/components";

let value: AgentObject = "agent";
```

## Values

```typescript
"agent"
```