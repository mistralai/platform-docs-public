# ToolExecutionStartedEventType

## Example Usage

```typescript
import { ToolExecutionStartedEventType } from "@mistralai/mistralai/models/components";

let value: ToolExecutionStartedEventType = "tool.execution.started";
```

## Values

```typescript
"tool.execution.started"
```