# ChatModerationRequestInputs

Chat to classify


## Supported Types

### `components.One[]`

```typescript
const value: components.One[] = [
  {
    content: null,
    role: "user",
  },
];
```

### `components.Two[][]`

```typescript
const value: components.Two[][] = [
  [],
];
```

