# ChatCompletionStreamRequestStop

Stop generation if this token is detected. Or if one of these tokens is detected when providing an array


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `List[str]`

```python
value: List[str] = /* values here */
```

