# Integrations


## Supported Types

### `components.WandbIntegrationOut`

```typescript
const value: components.WandbIntegrationOut = {
  project: "<value>",
};
```

