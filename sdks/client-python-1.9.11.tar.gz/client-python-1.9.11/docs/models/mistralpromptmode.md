# MistralPromptMode


## Values

| Name        | Value       |
| ----------- | ----------- |
| `REASONING` | reasoning   |