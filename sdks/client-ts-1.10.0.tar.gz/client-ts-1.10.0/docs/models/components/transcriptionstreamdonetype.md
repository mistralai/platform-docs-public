# TranscriptionStreamDoneType

## Example Usage

```typescript
import { TranscriptionStreamDoneType } from "@mistralai/mistralai/models/components";

let value: TranscriptionStreamDoneType = "transcription.done";
```

## Values

```typescript
"transcription.done"
```