# FunctionResultEntryObject

## Example Usage

```typescript
import { FunctionResultEntryObject } from "@mistralai/mistralai/models/components";

let value: FunctionResultEntryObject = "entry";
```

## Values

```typescript
"entry"
```