# ClassifierJobOutJobType

The type of job (`FT` for fine-tuning).


## Values

| Name         | Value        |
| ------------ | ------------ |
| `CLASSIFIER` | classifier   |