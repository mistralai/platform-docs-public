# BaseModelCardType

## Example Usage

```typescript
import { BaseModelCardType } from "@mistralai/mistralai/models/components";

let value: BaseModelCardType = "base";
```

## Values

```typescript
"base"
```