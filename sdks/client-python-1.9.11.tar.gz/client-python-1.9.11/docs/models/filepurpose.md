# FilePurpose


## Values

| Name        | Value       |
| ----------- | ----------- |
| `FINE_TUNE` | fine-tune   |
| `BATCH`     | batch       |
| `OCR`       | ocr         |