# ToolChoiceEnum


## Values

| Name       | Value      |
| ---------- | ---------- |
| `AUTO`     | auto       |
| `NONE`     | none       |
| `ANY`      | any        |
| `REQUIRED` | required   |