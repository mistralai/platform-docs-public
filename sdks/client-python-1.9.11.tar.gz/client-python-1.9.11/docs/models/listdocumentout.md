# ListDocumentOut


## Fields

| Field                                                | Type                                                 | Required                                             | Description                                          |
| ---------------------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------- |
| `pagination`                                         | [models.PaginationInfo](../models/paginationinfo.md) | :heavy_check_mark:                                   | N/A                                                  |
| `data`                                               | List[[models.DocumentOut](../models/documentout.md)] | :heavy_check_mark:                                   | N/A                                                  |