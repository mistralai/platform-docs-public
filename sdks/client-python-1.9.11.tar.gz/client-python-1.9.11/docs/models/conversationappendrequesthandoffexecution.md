# ConversationAppendRequestHandoffExecution


## Values

| Name     | Value    |
| -------- | -------- |
| `CLIENT` | client   |
| `SERVER` | server   |