# ResponseStartedEventType

## Example Usage

```typescript
import { ResponseStartedEventType } from "@mistralai/mistralai/models/components";

let value: ResponseStartedEventType = "conversation.response.started";
```

## Values

```typescript
"conversation.response.started"
```