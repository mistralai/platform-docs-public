# SystemMessage


## Fields

| Field                                                            | Type                                                             | Required                                                         | Description                                                      |
| ---------------------------------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------- |
| `content`                                                        | [models.SystemMessageContent](../models/systemmessagecontent.md) | :heavy_check_mark:                                               | N/A                                                              |
| `role`                                                           | [Optional[models.Role]](../models/role.md)                       | :heavy_minus_sign:                                               | N/A                                                              |