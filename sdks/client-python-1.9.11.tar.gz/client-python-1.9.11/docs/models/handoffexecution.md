# HandoffExecution


## Values

| Name     | Value    |
| -------- | -------- |
| `CLIENT` | client   |
| `SERVER` | server   |