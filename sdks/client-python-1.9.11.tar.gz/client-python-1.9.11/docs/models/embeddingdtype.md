# EmbeddingDtype


## Values

| Name      | Value     |
| --------- | --------- |
| `FLOAT`   | float     |
| `INT8`    | int8      |
| `UINT8`   | uint8     |
| `BINARY`  | binary    |
| `UBINARY` | ubinary   |