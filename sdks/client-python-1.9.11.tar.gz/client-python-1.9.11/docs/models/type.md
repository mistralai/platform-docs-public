# Type


## Values

| Name                    | Value                   |
| ----------------------- | ----------------------- |
| `TRANSCRIPTION_SEGMENT` | transcription_segment   |