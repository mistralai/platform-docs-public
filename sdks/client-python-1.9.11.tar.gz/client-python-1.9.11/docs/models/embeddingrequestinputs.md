# EmbeddingRequestInputs

Text to embed.


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `List[str]`

```python
value: List[str] = /* values here */
```

