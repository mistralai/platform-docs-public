# LibrariesShareCreateV1Request


## Fields

| Field                                      | Type                                       | Required                                   | Description                                |
| ------------------------------------------ | ------------------------------------------ | ------------------------------------------ | ------------------------------------------ |
| `library_id`                               | *str*                                      | :heavy_check_mark:                         | N/A                                        |
| `sharing_in`                               | [models.SharingIn](../models/sharingin.md) | :heavy_check_mark:                         | N/A                                        |