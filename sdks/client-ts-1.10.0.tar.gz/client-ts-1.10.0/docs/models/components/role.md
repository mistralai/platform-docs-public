# Role

## Example Usage

```typescript
import { Role } from "@mistralai/mistralai/models/components";

let value: Role = "system";
```

## Values

```typescript
"system"
```