# ModerationResponse


## Fields

| Field                                                          | Type                                                           | Required                                                       | Description                                                    | Example                                                        |
| -------------------------------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------- |
| `id`                                                           | *str*                                                          | :heavy_check_mark:                                             | N/A                                                            | mod-e5cc70bb28c444948073e77776eb30ef                           |
| `model`                                                        | *str*                                                          | :heavy_check_mark:                                             | N/A                                                            |                                                                |
| `results`                                                      | List[[models.ModerationObject](../models/moderationobject.md)] | :heavy_check_mark:                                             | N/A                                                            |                                                                |