# JobInRepositories


## Supported Types

### `models.GithubRepositoryIn`

```python
value: models.GithubRepositoryIn = /* values here */
```

