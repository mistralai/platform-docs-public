# FilesApiRoutesRetrieveFileRequest

## Example Usage

```typescript
import { FilesApiRoutesRetrieveFileRequest } from "@mistralai/mistralai/models/operations";

let value: FilesApiRoutesRetrieveFileRequest = {
  fileId: "29155a51-541e-4b6f-af8c-83f42faa7e22",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `fileId`           | *string*           | :heavy_check_mark: | N/A                |