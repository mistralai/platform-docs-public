# LibraryInUpdate


## Fields

| Field                   | Type                    | Required                | Description             |
| ----------------------- | ----------------------- | ----------------------- | ----------------------- |
| `name`                  | *OptionalNullable[str]* | :heavy_minus_sign:      | N/A                     |
| `description`           | *OptionalNullable[str]* | :heavy_minus_sign:      | N/A                     |