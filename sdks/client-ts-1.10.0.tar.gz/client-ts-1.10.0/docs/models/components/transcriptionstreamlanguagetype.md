# TranscriptionStreamLanguageType

## Example Usage

```typescript
import { TranscriptionStreamLanguageType } from "@mistralai/mistralai/models/components";

let value: TranscriptionStreamLanguageType = "transcription.language";
```

## Values

```typescript
"transcription.language"
```