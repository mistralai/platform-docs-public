# JobsApiRoutesFineTuningStartFineTuningJobRequest

## Example Usage

```typescript
import { JobsApiRoutesFineTuningStartFineTuningJobRequest } from "@mistralai/mistralai/models/operations";

let value: JobsApiRoutesFineTuningStartFineTuningJobRequest = {
  jobId: "5764212f-1795-4c4d-963a-27126a4c0a58",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `jobId`            | *string*           | :heavy_check_mark: | N/A                |