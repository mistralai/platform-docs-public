# ImageURLChunkImageURL


## Supported Types

### `components.ImageURL`

```typescript
const value: components.ImageURL = {
  url: "https://grim-farm.name/",
};
```

### `string`

```typescript
const value: string = "<value>";
```

