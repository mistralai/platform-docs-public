# AgentsAPIV1AgentsUpdateRequest


## Fields

| Field                                                        | Type                                                         | Required                                                     | Description                                                  |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| `agent_id`                                                   | *str*                                                        | :heavy_check_mark:                                           | N/A                                                          |
| `agent_update_request`                                       | [models.AgentUpdateRequest](../models/agentupdaterequest.md) | :heavy_check_mark:                                           | N/A                                                          |