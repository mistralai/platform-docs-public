# CompletionDetailedJobOutJobType

## Example Usage

```typescript
import { CompletionDetailedJobOutJobType } from "@mistralai/mistralai/models/components";

let value: CompletionDetailedJobOutJobType = "completion";
```

## Values

```typescript
"completion"
```