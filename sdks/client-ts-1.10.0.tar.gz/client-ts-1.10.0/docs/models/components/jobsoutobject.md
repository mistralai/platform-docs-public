# JobsOutObject

## Example Usage

```typescript
import { JobsOutObject } from "@mistralai/mistralai/models/components";

let value: JobsOutObject = "list";
```

## Values

```typescript
"list"
```