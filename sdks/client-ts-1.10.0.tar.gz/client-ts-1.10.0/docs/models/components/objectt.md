# ObjectT

## Example Usage

```typescript
import { ObjectT } from "@mistralai/mistralai/models/components";

let value: ObjectT = "entry";
```

## Values

```typescript
"entry"
```