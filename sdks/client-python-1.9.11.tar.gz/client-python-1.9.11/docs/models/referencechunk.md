# ReferenceChunk


## Fields

| Field                                                                  | Type                                                                   | Required                                                               | Description                                                            |
| ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| `reference_ids`                                                        | List[*int*]                                                            | :heavy_check_mark:                                                     | N/A                                                                    |
| `type`                                                                 | [Optional[models.ReferenceChunkType]](../models/referencechunktype.md) | :heavy_minus_sign:                                                     | N/A                                                                    |