# BatchJobOutObject


## Values

| Name    | Value   |
| ------- | ------- |
| `BATCH` | batch   |