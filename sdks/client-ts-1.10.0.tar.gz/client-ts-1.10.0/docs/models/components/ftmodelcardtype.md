# FTModelCardType

## Example Usage

```typescript
import { FTModelCardType } from "@mistralai/mistralai/models/components";

let value: FTModelCardType = "fine-tuned";
```

## Values

```typescript
"fine-tuned"
```