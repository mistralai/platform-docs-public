# FTModelCardType


## Values

| Name         | Value        |
| ------------ | ------------ |
| `FINE_TUNED` | fine-tuned   |