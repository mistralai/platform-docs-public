# ConversationAppendStreamRequestHandoffExecution

## Example Usage

```typescript
import { ConversationAppendStreamRequestHandoffExecution } from "@mistralai/mistralai/models/components";

let value: ConversationAppendStreamRequestHandoffExecution = "server";
```

## Values

```typescript
"client" | "server"
```