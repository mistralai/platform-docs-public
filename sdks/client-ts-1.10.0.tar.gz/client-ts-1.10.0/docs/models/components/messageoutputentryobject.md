# MessageOutputEntryObject

## Example Usage

```typescript
import { MessageOutputEntryObject } from "@mistralai/mistralai/models/components";

let value: MessageOutputEntryObject = "entry";
```

## Values

```typescript
"entry"
```