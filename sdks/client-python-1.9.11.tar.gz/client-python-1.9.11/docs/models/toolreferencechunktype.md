# ToolReferenceChunkType


## Values

| Name             | Value            |
| ---------------- | ---------------- |
| `TOOL_REFERENCE` | tool_reference   |