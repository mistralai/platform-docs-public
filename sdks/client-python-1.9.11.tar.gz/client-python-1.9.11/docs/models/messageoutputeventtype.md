# MessageOutputEventType


## Values

| Name                   | Value                  |
| ---------------------- | ---------------------- |
| `MESSAGE_OUTPUT_DELTA` | message.output.delta   |