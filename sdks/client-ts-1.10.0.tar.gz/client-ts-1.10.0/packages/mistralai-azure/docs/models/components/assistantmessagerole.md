# AssistantMessageRole

## Example Usage

```typescript
import { AssistantMessageRole } from "@mistralai/mistralai-azure/models/components";

let value: AssistantMessageRole = "assistant";
```

## Values

```typescript
"assistant"
```