# TimestampGranularity

## Example Usage

```typescript
import { TimestampGranularity } from "@mistralai/mistralai/models/components";

let value: TimestampGranularity = "segment";
```

## Values

```typescript
"segment"
```