# TranscriptionStreamLanguageType


## Values

| Name                     | Value                    |
| ------------------------ | ------------------------ |
| `TRANSCRIPTION_LANGUAGE` | transcription.language   |