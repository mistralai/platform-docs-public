# ArchiveFTModelOutObject

## Example Usage

```typescript
import { ArchiveFTModelOutObject } from "@mistralai/mistralai/models/components";

let value: ArchiveFTModelOutObject = "model";
```

## Values

```typescript
"model"
```