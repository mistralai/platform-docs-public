# Document

Document to run OCR on


## Supported Types

### `models.FileChunk`

```python
value: models.FileChunk = /* values here */
```

### `models.DocumentURLChunk`

```python
value: models.DocumentURLChunk = /* values here */
```

### `models.ImageURLChunk`

```python
value: models.ImageURLChunk = /* values here */
```

