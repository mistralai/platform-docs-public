# BatchJobOutObject

## Example Usage

```typescript
import { BatchJobOutObject } from "@mistralai/mistralai/models/components";

let value: BatchJobOutObject = "batch";
```

## Values

```typescript
"batch"
```