# BatchJobsOutObject


## Values

| Name   | Value  |
| ------ | ------ |
| `LIST` | list   |