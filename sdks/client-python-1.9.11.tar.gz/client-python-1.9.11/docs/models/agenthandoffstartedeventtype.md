# AgentHandoffStartedEventType


## Values

| Name                    | Value                   |
| ----------------------- | ----------------------- |
| `AGENT_HANDOFF_STARTED` | agent.handoff.started   |