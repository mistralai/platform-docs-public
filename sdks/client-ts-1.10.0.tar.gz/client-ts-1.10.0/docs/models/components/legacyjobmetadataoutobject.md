# LegacyJobMetadataOutObject

## Example Usage

```typescript
import { LegacyJobMetadataOutObject } from "@mistralai/mistralai/models/components";

let value: LegacyJobMetadataOutObject = "job.metadata";
```

## Values

```typescript
"job.metadata"
```