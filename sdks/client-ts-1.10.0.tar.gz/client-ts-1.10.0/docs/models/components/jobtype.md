# JobType

The type of job (`FT` for fine-tuning).

## Example Usage

```typescript
import { JobType } from "@mistralai/mistralai/models/components";

let value: JobType = "completion";
```

## Values

```typescript
"completion"
```