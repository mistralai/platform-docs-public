# MessageInputEntryType


## Values

| Name            | Value           |
| --------------- | --------------- |
| `MESSAGE_INPUT` | message.input   |