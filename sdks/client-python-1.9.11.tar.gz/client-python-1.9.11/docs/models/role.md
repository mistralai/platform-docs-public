# Role


## Values

| Name     | Value    |
| -------- | -------- |
| `SYSTEM` | system   |