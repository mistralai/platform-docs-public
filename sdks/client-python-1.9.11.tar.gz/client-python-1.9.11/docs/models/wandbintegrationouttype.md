# WandbIntegrationOutType


## Values

| Name    | Value   |
| ------- | ------- |
| `WANDB` | wandb   |