# ImageURLChunkImageURL


## Supported Types

### `models.ImageURL`

```python
value: models.ImageURL = /* values here */
```

### `str`

```python
value: str = /* values here */
```

