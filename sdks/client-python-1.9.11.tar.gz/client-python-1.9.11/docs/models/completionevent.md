# CompletionEvent


## Fields

| Field                                                  | Type                                                   | Required                                               | Description                                            |
| ------------------------------------------------------ | ------------------------------------------------------ | ------------------------------------------------------ | ------------------------------------------------------ |
| `data`                                                 | [models.CompletionChunk](../models/completionchunk.md) | :heavy_check_mark:                                     | N/A                                                    |