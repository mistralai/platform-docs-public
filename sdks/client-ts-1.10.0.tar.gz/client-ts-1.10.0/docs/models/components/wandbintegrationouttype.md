# WandbIntegrationOutType

## Example Usage

```typescript
import { WandbIntegrationOutType } from "@mistralai/mistralai/models/components";

let value: WandbIntegrationOutType = "wandb";
```

## Values

```typescript
"wandb"
```