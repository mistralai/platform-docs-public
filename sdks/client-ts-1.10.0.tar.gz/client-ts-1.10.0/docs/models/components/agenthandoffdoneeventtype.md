# AgentHandoffDoneEventType

## Example Usage

```typescript
import { AgentHandoffDoneEventType } from "@mistralai/mistralai/models/components";

let value: AgentHandoffDoneEventType = "agent.handoff.done";
```

## Values

```typescript
"agent.handoff.done"
```