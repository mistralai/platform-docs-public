# ToolExecutionEntryObject

## Example Usage

```typescript
import { ToolExecutionEntryObject } from "@mistralai/mistralai/models/components";

let value: ToolExecutionEntryObject = "entry";
```

## Values

```typescript
"entry"
```