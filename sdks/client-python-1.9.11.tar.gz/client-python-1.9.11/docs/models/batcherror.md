# BatchError


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `message`          | *str*              | :heavy_check_mark: | N/A                |
| `count`            | *Optional[int]*    | :heavy_minus_sign: | N/A                |