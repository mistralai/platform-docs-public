# MessageOutputEntryType

## Example Usage

```typescript
import { MessageOutputEntryType } from "@mistralai/mistralai/models/components";

let value: MessageOutputEntryType = "message.output";
```

## Values

```typescript
"message.output"
```