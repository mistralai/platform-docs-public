# AgentObject


## Values

| Name    | Value   |
| ------- | ------- |
| `AGENT` | agent   |