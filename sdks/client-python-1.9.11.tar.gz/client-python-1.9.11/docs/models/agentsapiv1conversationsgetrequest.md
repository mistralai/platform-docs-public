# AgentsAPIV1ConversationsGetRequest


## Fields

| Field                                                       | Type                                                        | Required                                                    | Description                                                 |
| ----------------------------------------------------------- | ----------------------------------------------------------- | ----------------------------------------------------------- | ----------------------------------------------------------- |
| `conversation_id`                                           | *str*                                                       | :heavy_check_mark:                                          | ID of the conversation from which we are fetching metadata. |