# ReferenceChunkType


## Values

| Name        | Value       |
| ----------- | ----------- |
| `REFERENCE` | reference   |