# LibrariesUpdateV1Request


## Fields

| Field                                                  | Type                                                   | Required                                               | Description                                            |
| ------------------------------------------------------ | ------------------------------------------------------ | ------------------------------------------------------ | ------------------------------------------------------ |
| `library_id`                                           | *str*                                                  | :heavy_check_mark:                                     | N/A                                                    |
| `library_in_update`                                    | [models.LibraryInUpdate](../models/libraryinupdate.md) | :heavy_check_mark:                                     | N/A                                                    |