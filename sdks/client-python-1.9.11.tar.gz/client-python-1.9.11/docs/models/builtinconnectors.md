# BuiltInConnectors


## Values

| Name                 | Value                |
| -------------------- | -------------------- |
| `WEB_SEARCH`         | web_search           |
| `WEB_SEARCH_PREMIUM` | web_search_premium   |
| `CODE_INTERPRETER`   | code_interpreter     |
| `IMAGE_GENERATION`   | image_generation     |
| `DOCUMENT_LIBRARY`   | document_library     |