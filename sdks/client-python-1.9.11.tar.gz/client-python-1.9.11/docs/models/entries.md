# Entries


## Supported Types

### `models.MessageInputEntry`

```python
value: models.MessageInputEntry = /* values here */
```

### `models.MessageOutputEntry`

```python
value: models.MessageOutputEntry = /* values here */
```

### `models.FunctionResultEntry`

```python
value: models.FunctionResultEntry = /* values here */
```

### `models.FunctionCallEntry`

```python
value: models.FunctionCallEntry = /* values here */
```

### `models.ToolExecutionEntry`

```python
value: models.ToolExecutionEntry = /* values here */
```

### `models.AgentHandoffEntry`

```python
value: models.AgentHandoffEntry = /* values here */
```

