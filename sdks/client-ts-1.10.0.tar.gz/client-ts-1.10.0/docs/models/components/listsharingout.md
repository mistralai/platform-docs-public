# ListSharingOut

## Example Usage

```typescript
import { ListSharingOut } from "@mistralai/mistralai/models/components";

let value: ListSharingOut = {
  data: [],
};
```

## Fields

| Field                                                            | Type                                                             | Required                                                         | Description                                                      |
| ---------------------------------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------- |
| `data`                                                           | [components.SharingOut](../../models/components/sharingout.md)[] | :heavy_check_mark:                                               | N/A                                                              |