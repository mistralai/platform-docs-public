# DocumentURLChunkType


## Values

| Name           | Value          |
| -------------- | -------------- |
| `DOCUMENT_URL` | document_url   |