# ConversationRestartRequestHandoffExecution

## Example Usage

```typescript
import { ConversationRestartRequestHandoffExecution } from "@mistralai/mistralai/models/components";

let value: ConversationRestartRequestHandoffExecution = "server";
```

## Values

```typescript
"client" | "server"
```