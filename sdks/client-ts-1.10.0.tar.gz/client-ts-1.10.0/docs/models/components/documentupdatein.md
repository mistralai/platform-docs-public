# DocumentUpdateIn

## Example Usage

```typescript
import { DocumentUpdateIn } from "@mistralai/mistralai/models/components";

let value: DocumentUpdateIn = {};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `name`             | *string*           | :heavy_minus_sign: | N/A                |