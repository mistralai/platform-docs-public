# Security


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `api_key`          | *Optional[str]*    | :heavy_minus_sign: | N/A                |