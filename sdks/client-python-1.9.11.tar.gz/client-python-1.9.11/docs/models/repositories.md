# Repositories


## Supported Types

### `models.GithubRepositoryOut`

```python
value: models.GithubRepositoryOut = /* values here */
```

