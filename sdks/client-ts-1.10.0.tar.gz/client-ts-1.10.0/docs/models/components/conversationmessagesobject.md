# ConversationMessagesObject

## Example Usage

```typescript
import { ConversationMessagesObject } from "@mistralai/mistralai/models/components";

let value: ConversationMessagesObject = "conversation.messages";
```

## Values

```typescript
"conversation.messages"
```