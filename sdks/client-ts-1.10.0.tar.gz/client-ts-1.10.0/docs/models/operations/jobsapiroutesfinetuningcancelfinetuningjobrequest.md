# JobsApiRoutesFineTuningCancelFineTuningJobRequest

## Example Usage

```typescript
import { JobsApiRoutesFineTuningCancelFineTuningJobRequest } from "@mistralai/mistralai/models/operations";

let value: JobsApiRoutesFineTuningCancelFineTuningJobRequest = {
  jobId: "180bc5c4-f0e2-4324-a170-ad3622d33a6a",
};
```

## Fields

| Field                        | Type                         | Required                     | Description                  |
| ---------------------------- | ---------------------------- | ---------------------------- | ---------------------------- |
| `jobId`                      | *string*                     | :heavy_check_mark:           | The ID of the job to cancel. |