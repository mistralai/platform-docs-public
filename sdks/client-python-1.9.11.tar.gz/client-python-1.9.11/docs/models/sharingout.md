# SharingOut


## Fields

| Field                   | Type                    | Required                | Description             |
| ----------------------- | ----------------------- | ----------------------- | ----------------------- |
| `library_id`            | *str*                   | :heavy_check_mark:      | N/A                     |
| `user_id`               | *OptionalNullable[str]* | :heavy_minus_sign:      | N/A                     |
| `org_id`                | *str*                   | :heavy_check_mark:      | N/A                     |
| `role`                  | *str*                   | :heavy_check_mark:      | N/A                     |
| `share_with_type`       | *str*                   | :heavy_check_mark:      | N/A                     |
| `share_with_uuid`       | *str*                   | :heavy_check_mark:      | N/A                     |