# ChatCompletionStreamRequestToolChoice


## Supported Types

### `models.ToolChoice`

```python
value: models.ToolChoice = /* values here */
```

### `models.ToolChoiceEnum`

```python
value: models.ToolChoiceEnum = /* values here */
```

