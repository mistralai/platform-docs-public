# LibrariesShareListV1Request

## Example Usage

```typescript
import { LibrariesShareListV1Request } from "@mistralai/mistralai/models/operations";

let value: LibrariesShareListV1Request = {
  libraryId: "794dd27b-b377-4ac7-858d-f1616f11b0b5",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `libraryId`        | *string*           | :heavy_check_mark: | N/A                |