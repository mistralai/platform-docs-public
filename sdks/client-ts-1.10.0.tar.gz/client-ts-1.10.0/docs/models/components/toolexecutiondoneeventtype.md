# ToolExecutionDoneEventType

## Example Usage

```typescript
import { ToolExecutionDoneEventType } from "@mistralai/mistralai/models/components";

let value: ToolExecutionDoneEventType = "tool.execution.done";
```

## Values

```typescript
"tool.execution.done"
```