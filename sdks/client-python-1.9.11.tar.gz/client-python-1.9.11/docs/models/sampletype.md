# SampleType


## Values

| Name            | Value           |
| --------------- | --------------- |
| `PRETRAIN`      | pretrain        |
| `INSTRUCT`      | instruct        |
| `BATCH_REQUEST` | batch_request   |
| `BATCH_RESULT`  | batch_result    |
| `BATCH_ERROR`   | batch_error     |