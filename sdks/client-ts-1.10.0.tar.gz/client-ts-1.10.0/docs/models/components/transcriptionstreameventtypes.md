# TranscriptionStreamEventTypes

## Example Usage

```typescript
import { TranscriptionStreamEventTypes } from "@mistralai/mistralai/models/components";

let value: TranscriptionStreamEventTypes = "transcription.text.delta";
```

## Values

```typescript
"transcription.language" | "transcription.segment" | "transcription.text.delta" | "transcription.done"
```