# ModerationObject


## Fields

| Field                        | Type                         | Required                     | Description                  |
| ---------------------------- | ---------------------------- | ---------------------------- | ---------------------------- |
| `categories`                 | Dict[str, *bool*]            | :heavy_minus_sign:           | Moderation result thresholds |
| `category_scores`            | Dict[str, *float*]           | :heavy_minus_sign:           | Moderation result            |