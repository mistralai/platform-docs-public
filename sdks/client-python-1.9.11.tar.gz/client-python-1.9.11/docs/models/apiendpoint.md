# APIEndpoint


## Values

| Name                           | Value                          |
| ------------------------------ | ------------------------------ |
| `ROOT_V1_CHAT_COMPLETIONS`     | /v1/chat/completions           |
| `ROOT_V1_EMBEDDINGS`           | /v1/embeddings                 |
| `ROOT_V1_FIM_COMPLETIONS`      | /v1/fim/completions            |
| `ROOT_V1_MODERATIONS`          | /v1/moderations                |
| `ROOT_V1_CHAT_MODERATIONS`     | /v1/chat/moderations           |
| `ROOT_V1_OCR`                  | /v1/ocr                        |
| `ROOT_V1_CLASSIFICATIONS`      | /v1/classifications            |
| `ROOT_V1_CHAT_CLASSIFICATIONS` | /v1/chat/classifications       |
| `ROOT_V1_CONVERSATIONS`        | /v1/conversations              |
| `ROOT_V1_AUDIO_TRANSCRIPTIONS` | /v1/audio/transcriptions       |