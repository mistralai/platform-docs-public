# LibrariesDeleteV1Request

## Example Usage

```typescript
import { LibrariesDeleteV1Request } from "@mistralai/mistralai/models/operations";

let value: LibrariesDeleteV1Request = {
  libraryId: "8b9c91e9-8a8f-4975-9719-7d6fcd17bb8b",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `libraryId`        | *string*           | :heavy_check_mark: | N/A                |