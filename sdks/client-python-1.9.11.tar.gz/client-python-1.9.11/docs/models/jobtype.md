# JobType

The type of job (`FT` for fine-tuning).


## Values

| Name         | Value        |
| ------------ | ------------ |
| `COMPLETION` | completion   |