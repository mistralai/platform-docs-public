# Prediction


## Fields

| Field                          | Type                           | Required                       | Description                    |
| ------------------------------ | ------------------------------ | ------------------------------ | ------------------------------ |
| `type`                         | *Optional[Literal["content"]]* | :heavy_minus_sign:             | N/A                            |
| `content`                      | *Optional[str]*                | :heavy_minus_sign:             | N/A                            |