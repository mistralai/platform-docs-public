# ResponseBody


## Supported Types

### `models.ModelConversation`

```python
value: models.ModelConversation = /* values here */
```

### `models.AgentConversation`

```python
value: models.AgentConversation = /* values here */
```

