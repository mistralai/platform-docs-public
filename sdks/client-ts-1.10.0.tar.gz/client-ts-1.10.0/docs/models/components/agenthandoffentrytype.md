# AgentHandoffEntryType

## Example Usage

```typescript
import { AgentHandoffEntryType } from "@mistralai/mistralai/models/components";

let value: AgentHandoffEntryType = "agent.handoff";
```

## Values

```typescript
"agent.handoff"
```