# Type

## Example Usage

```typescript
import { Type } from "@mistralai/mistralai/models/components";

let value: Type = "transcription_segment";
```

## Values

```typescript
"transcription_segment"
```