# ConversationRestartStreamRequestHandoffExecution

## Example Usage

```typescript
import { ConversationRestartStreamRequestHandoffExecution } from "@mistralai/mistralai/models/components";

let value: ConversationRestartStreamRequestHandoffExecution = "server";
```

## Values

```typescript
"client" | "server"
```