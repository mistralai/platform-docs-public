# AgentsAPIV1AgentsUpdateVersionRequest


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `agent_id`         | *str*              | :heavy_check_mark: | N/A                |
| `version`          | *int*              | :heavy_check_mark: | N/A                |