# JobsApiRoutesBatchGetBatchJobRequest

## Example Usage

```typescript
import { JobsApiRoutesBatchGetBatchJobRequest } from "@mistralai/mistralai/models/operations";

let value: JobsApiRoutesBatchGetBatchJobRequest = {
  jobId: "ab89e3eb-a108-4a95-82e3-7e1941a586e1",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `jobId`            | *string*           | :heavy_check_mark: | N/A                |