# ClassifierJobOutJobType

The type of job (`FT` for fine-tuning).

## Example Usage

```typescript
import { ClassifierJobOutJobType } from "@mistralai/mistralai/models/components";

let value: ClassifierJobOutJobType = "classifier";
```

## Values

```typescript
"classifier"
```