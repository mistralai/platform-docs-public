# AudioChunk


## Fields

| Field                                                          | Type                                                           | Required                                                       | Description                                                    |
| -------------------------------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------- |
| `input_audio`                                                  | *str*                                                          | :heavy_check_mark:                                             | N/A                                                            |
| `type`                                                         | [Optional[models.AudioChunkType]](../models/audiochunktype.md) | :heavy_minus_sign:                                             | N/A                                                            |