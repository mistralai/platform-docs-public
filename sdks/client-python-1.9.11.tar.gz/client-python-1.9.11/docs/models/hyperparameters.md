# Hyperparameters


## Supported Types

### `models.CompletionTrainingParametersIn`

```python
value: models.CompletionTrainingParametersIn = /* values here */
```

### `models.ClassifierTrainingParametersIn`

```python
value: models.ClassifierTrainingParametersIn = /* values here */
```

