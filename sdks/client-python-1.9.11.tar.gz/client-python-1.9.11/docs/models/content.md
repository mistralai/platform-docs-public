# Content


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `List[models.ContentChunk]`

```python
value: List[models.ContentChunk] = /* values here */
```

