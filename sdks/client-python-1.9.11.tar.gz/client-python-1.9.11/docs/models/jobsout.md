# JobsOut


## Fields

| Field                                                        | Type                                                         | Required                                                     | Description                                                  |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| `data`                                                       | List[[models.JobsOutData](../models/jobsoutdata.md)]         | :heavy_minus_sign:                                           | N/A                                                          |
| `object`                                                     | [Optional[models.JobsOutObject]](../models/jobsoutobject.md) | :heavy_minus_sign:                                           | N/A                                                          |
| `total`                                                      | *int*                                                        | :heavy_check_mark:                                           | N/A                                                          |