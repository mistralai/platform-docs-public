# WebSearchToolType


## Values

| Name         | Value        |
| ------------ | ------------ |
| `WEB_SEARCH` | web_search   |