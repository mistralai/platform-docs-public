# MessageOutputEventContent


## Supported Types

### `string`

```typescript
const value: string = "<value>";
```

### `components.OutputContentChunks`

```typescript
const value: components.OutputContentChunks = {
  documentUrl: "https://super-tool.biz",
  type: "document_url",
};
```

