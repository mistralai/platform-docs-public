# AudioChunkType

## Example Usage

```typescript
import { AudioChunkType } from "@mistralai/mistralai/models/components";

let value: AudioChunkType = "input_audio";
```

## Values

```typescript
"input_audio"
```