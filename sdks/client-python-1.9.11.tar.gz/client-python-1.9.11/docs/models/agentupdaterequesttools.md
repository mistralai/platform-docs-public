# AgentUpdateRequestTools


## Supported Types

### `models.CodeInterpreterTool`

```python
value: models.CodeInterpreterTool = /* values here */
```

### `models.DocumentLibraryTool`

```python
value: models.DocumentLibraryTool = /* values here */
```

### `models.FunctionTool`

```python
value: models.FunctionTool = /* values here */
```

### `models.ImageGenerationTool`

```python
value: models.ImageGenerationTool = /* values here */
```

### `models.WebSearchTool`

```python
value: models.WebSearchTool = /* values here */
```

### `models.WebSearchPremiumTool`

```python
value: models.WebSearchPremiumTool = /* values here */
```

