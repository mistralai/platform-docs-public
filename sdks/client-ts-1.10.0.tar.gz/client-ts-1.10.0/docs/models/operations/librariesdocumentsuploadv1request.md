# LibrariesDocumentsUploadV1Request

## Example Usage

```typescript
import { LibrariesDocumentsUploadV1Request } from "@mistralai/mistralai/models/operations";

// No examples available for this model
```

## Fields

| Field                                                                                                                      | Type                                                                                                                       | Required                                                                                                                   | Description                                                                                                                |
| -------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `libraryId`                                                                                                                | *string*                                                                                                                   | :heavy_check_mark:                                                                                                         | N/A                                                                                                                        |
| `requestBody`                                                                                                              | [operations.LibrariesDocumentsUploadV1DocumentUpload](../../models/operations/librariesdocumentsuploadv1documentupload.md) | :heavy_check_mark:                                                                                                         | N/A                                                                                                                        |