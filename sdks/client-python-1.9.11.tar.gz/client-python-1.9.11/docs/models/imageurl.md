# ImageURL


## Fields

| Field                   | Type                    | Required                | Description             |
| ----------------------- | ----------------------- | ----------------------- | ----------------------- |
| `url`                   | *str*                   | :heavy_check_mark:      | N/A                     |
| `detail`                | *OptionalNullable[str]* | :heavy_minus_sign:      | N/A                     |