# FunctionCallEntryObject

## Example Usage

```typescript
import { FunctionCallEntryObject } from "@mistralai/mistralai/models/components";

let value: FunctionCallEntryObject = "entry";
```

## Values

```typescript
"entry"
```