# TextChunkType


## Values

| Name   | Value  |
| ------ | ------ |
| `TEXT` | text   |