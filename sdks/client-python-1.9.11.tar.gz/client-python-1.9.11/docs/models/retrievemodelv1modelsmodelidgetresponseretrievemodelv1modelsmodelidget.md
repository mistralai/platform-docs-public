# RetrieveModelV1ModelsModelIDGetResponseRetrieveModelV1ModelsModelIDGet

Successful Response


## Supported Types

### `models.BaseModelCard`

```python
value: models.BaseModelCard = /* values here */
```

### `models.FTModelCard`

```python
value: models.FTModelCard = /* values here */
```

