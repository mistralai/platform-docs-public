# AgentsAPIV1ConversationsAppendRequest


## Fields

| Field                                                                      | Type                                                                       | Required                                                                   | Description                                                                |
| -------------------------------------------------------------------------- | -------------------------------------------------------------------------- | -------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| `conversation_id`                                                          | *str*                                                                      | :heavy_check_mark:                                                         | ID of the conversation to which we append entries.                         |
| `conversation_append_request`                                              | [models.ConversationAppendRequest](../models/conversationappendrequest.md) | :heavy_check_mark:                                                         | N/A                                                                        |