# Arguments


## Supported Types

### `{ [k: string]: any }`

```typescript
const value: { [k: string]: any } = {
  "key": "<value>",
};
```

### `string`

```typescript
const value: string = "<value>";
```

