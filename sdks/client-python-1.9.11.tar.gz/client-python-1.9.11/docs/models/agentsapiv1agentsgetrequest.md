# AgentsAPIV1AgentsGetRequest


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `agent_id`         | *str*              | :heavy_check_mark: | N/A                |