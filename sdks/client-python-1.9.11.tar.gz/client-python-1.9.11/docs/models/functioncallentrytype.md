# FunctionCallEntryType


## Values

| Name            | Value           |
| --------------- | --------------- |
| `FUNCTION_CALL` | function.call   |