# FineTuneableModelType

## Example Usage

```typescript
import { FineTuneableModelType } from "@mistralai/mistralai/models/components";

let value: FineTuneableModelType = "classifier";
```

## Values

```typescript
"completion" | "classifier"
```