# ResponseDoneEventType

## Example Usage

```typescript
import { ResponseDoneEventType } from "@mistralai/mistralai/models/components";

let value: ResponseDoneEventType = "conversation.response.done";
```

## Values

```typescript
"conversation.response.done"
```