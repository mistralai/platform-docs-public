# HandoffExecution

## Example Usage

```typescript
import { HandoffExecution } from "@mistralai/mistralai/models/components";

let value: HandoffExecution = "server";
```

## Values

```typescript
"client" | "server"
```