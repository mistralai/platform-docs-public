# EmbeddingRequestInputs

Text to embed.


## Supported Types

### `string`

```typescript
const value: string = "[\"Embed this sentence.\",\"As well as this one.\"]";
```

### `string[]`

```typescript
const value: string[] = [
  "Embed this sentence.",
  "As well as this one.",
];
```

