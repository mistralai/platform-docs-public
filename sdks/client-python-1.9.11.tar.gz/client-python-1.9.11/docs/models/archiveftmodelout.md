# ArchiveFTModelOut


## Fields

| Field                                                                            | Type                                                                             | Required                                                                         | Description                                                                      |
| -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| `id`                                                                             | *str*                                                                            | :heavy_check_mark:                                                               | N/A                                                                              |
| `object`                                                                         | [Optional[models.ArchiveFTModelOutObject]](../models/archiveftmodeloutobject.md) | :heavy_minus_sign:                                                               | N/A                                                                              |
| `archived`                                                                       | *Optional[bool]*                                                                 | :heavy_minus_sign:                                                               | N/A                                                                              |