# DocumentLibraryToolType


## Values

| Name               | Value              |
| ------------------ | ------------------ |
| `DOCUMENT_LIBRARY` | document_library   |