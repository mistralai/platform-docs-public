# FineTuneableModelType


## Values

| Name         | Value        |
| ------------ | ------------ |
| `COMPLETION` | completion   |
| `CLASSIFIER` | classifier   |