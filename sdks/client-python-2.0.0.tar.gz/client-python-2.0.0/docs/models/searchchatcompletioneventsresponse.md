# SearchChatCompletionEventsResponse


## Fields

| Field                                                                                            | Type                                                                                             | Required                                                                                         | Description                                                                                      |
| ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------ |
| `completion_events`                                                                              | [models.FeedResultChatCompletionEventPreview](../models/feedresultchatcompletioneventpreview.md) | :heavy_check_mark:                                                                               | N/A                                                                                              |