# TranscriptionStreamEvents


## Fields

| Field                                                                              | Type                                                                               | Required                                                                           | Description                                                                        |
| ---------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| `event`                                                                            | [models.TranscriptionStreamEventTypes](../models/transcriptionstreameventtypes.md) | :heavy_check_mark:                                                                 | N/A                                                                                |
| `data`                                                                             | [models.TranscriptionStreamEventsData](../models/transcriptionstreameventsdata.md) | :heavy_check_mark:                                                                 | N/A                                                                                |