# ClassifierDetailedJobOutStatus


## Values

| Name                     | Value                    |
| ------------------------ | ------------------------ |
| `QUEUED`                 | QUEUED                   |
| `STARTED`                | STARTED                  |
| `VALIDATING`             | VALIDATING               |
| `VALIDATED`              | VALIDATED                |
| `RUNNING`                | RUNNING                  |
| `FAILED_VALIDATION`      | FAILED_VALIDATION        |
| `FAILED`                 | FAILED                   |
| `SUCCESS`                | SUCCESS                  |
| `CANCELLED`              | CANCELLED                |
| `CANCELLATION_REQUESTED` | CANCELLATION_REQUESTED   |