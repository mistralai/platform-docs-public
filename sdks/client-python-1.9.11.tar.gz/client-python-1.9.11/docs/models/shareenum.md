# ShareEnum


## Values

| Name     | Value    |
| -------- | -------- |
| `VIEWER` | Viewer   |
| `EDITOR` | Editor   |