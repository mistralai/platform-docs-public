# AgentHandoffDoneEventType


## Values

| Name                 | Value                |
| -------------------- | -------------------- |
| `AGENT_HANDOFF_DONE` | agent.handoff.done   |