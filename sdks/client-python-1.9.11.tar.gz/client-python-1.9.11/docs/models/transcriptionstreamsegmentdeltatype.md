# TranscriptionStreamSegmentDeltaType


## Values

| Name                    | Value                   |
| ----------------------- | ----------------------- |
| `TRANSCRIPTION_SEGMENT` | transcription.segment   |