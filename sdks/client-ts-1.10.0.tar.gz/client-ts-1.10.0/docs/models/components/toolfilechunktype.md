# ToolFileChunkType

## Example Usage

```typescript
import { ToolFileChunkType } from "@mistralai/mistralai/models/components";

let value: ToolFileChunkType = "tool_file";
```

## Values

```typescript
"tool_file"
```