# LibrariesGetV1Request

## Example Usage

```typescript
import { LibrariesGetV1Request } from "@mistralai/mistralai/models/operations";

let value: LibrariesGetV1Request = {
  libraryId: "46b5cb01-2c69-4b8a-a328-d29fb35f2446",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `libraryId`        | *string*           | :heavy_check_mark: | N/A                |