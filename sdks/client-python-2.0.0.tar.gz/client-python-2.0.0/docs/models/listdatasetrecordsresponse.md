# ListDatasetRecordsResponse


## Fields

| Field                                                                            | Type                                                                             | Required                                                                         | Description                                                                      |
| -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| `records`                                                                        | [models.PaginatedResultDatasetRecord](../models/paginatedresultdatasetrecord.md) | :heavy_check_mark:                                                               | N/A                                                                              |