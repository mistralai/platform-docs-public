# CompletionDetailedJobOutObject


## Values

| Name  | Value |
| ----- | ----- |
| `JOB` | job   |