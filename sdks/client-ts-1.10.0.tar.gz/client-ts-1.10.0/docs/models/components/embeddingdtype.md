# EmbeddingDtype

## Example Usage

```typescript
import { EmbeddingDtype } from "@mistralai/mistralai/models/components";

let value: EmbeddingDtype = "int8";
```

## Values

```typescript
"float" | "int8" | "uint8" | "binary" | "ubinary"
```