# ProcessingStatusOut


## Fields

| Field               | Type                | Required            | Description         |
| ------------------- | ------------------- | ------------------- | ------------------- |
| `document_id`       | *str*               | :heavy_check_mark:  | N/A                 |
| `processing_status` | *str*               | :heavy_check_mark:  | N/A                 |