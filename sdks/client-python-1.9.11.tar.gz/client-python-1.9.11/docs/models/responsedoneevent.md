# ResponseDoneEvent


## Fields

| Field                                                                        | Type                                                                         | Required                                                                     | Description                                                                  |
| ---------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `type`                                                                       | [Optional[models.ResponseDoneEventType]](../models/responsedoneeventtype.md) | :heavy_minus_sign:                                                           | N/A                                                                          |
| `created_at`                                                                 | [date](https://docs.python.org/3/library/datetime.html#date-objects)         | :heavy_minus_sign:                                                           | N/A                                                                          |
| `usage`                                                                      | [models.ConversationUsageInfo](../models/conversationusageinfo.md)           | :heavy_check_mark:                                                           | N/A                                                                          |