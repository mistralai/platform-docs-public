# CompletionDetailedJobOutObject

## Example Usage

```typescript
import { CompletionDetailedJobOutObject } from "@mistralai/mistralai/models/components";

let value: CompletionDetailedJobOutObject = "job";
```

## Values

```typescript
"job"
```