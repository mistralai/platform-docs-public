# ConversationHistory

Retrieve all entries in a conversation.


## Fields

| Field                                       | Type                                        | Required                                    | Description                                 |
| ------------------------------------------- | ------------------------------------------- | ------------------------------------------- | ------------------------------------------- |
| `object`                                    | *Optional[Literal["conversation.history"]]* | :heavy_minus_sign:                          | N/A                                         |
| `conversation_id`                           | *str*                                       | :heavy_check_mark:                          | N/A                                         |
| `entries`                                   | List[[models.Entry](../models/entry.md)]    | :heavy_check_mark:                          | N/A                                         |