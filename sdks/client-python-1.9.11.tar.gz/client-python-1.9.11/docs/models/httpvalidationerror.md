# HTTPValidationError


## Fields

| Field                                                        | Type                                                         | Required                                                     | Description                                                  |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| `detail`                                                     | List[[models.ValidationError](../models/validationerror.md)] | :heavy_minus_sign:                                           | N/A                                                          |