# MessageOutputEventContent


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `models.OutputContentChunks`

```python
value: models.OutputContentChunks = /* values here */
```

