# ToolExecutionStartedEventType


## Values

| Name                     | Value                    |
| ------------------------ | ------------------------ |
| `TOOL_EXECUTION_STARTED` | tool.execution.started   |