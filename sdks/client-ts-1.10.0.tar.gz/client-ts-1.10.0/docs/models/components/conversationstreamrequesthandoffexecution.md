# ConversationStreamRequestHandoffExecution

## Example Usage

```typescript
import { ConversationStreamRequestHandoffExecution } from "@mistralai/mistralai/models/components";

let value: ConversationStreamRequestHandoffExecution = "server";
```

## Values

```typescript
"client" | "server"
```