# BaseModelCardType


## Values

| Name   | Value  |
| ------ | ------ |
| `BASE` | base   |