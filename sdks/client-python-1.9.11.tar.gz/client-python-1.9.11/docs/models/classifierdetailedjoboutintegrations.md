# ClassifierDetailedJobOutIntegrations


## Supported Types

### `models.WandbIntegrationOut`

```python
value: models.WandbIntegrationOut = /* values here */
```

