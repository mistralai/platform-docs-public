# Repositories


## Supported Types

### `components.GithubRepositoryOut`

```typescript
const value: components.GithubRepositoryOut = {
  name: "<value>",
  owner: "<value>",
  commitId: "<id>",
};
```

