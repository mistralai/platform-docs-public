# FileChunk


## Fields

| Field                       | Type                        | Required                    | Description                 |
| --------------------------- | --------------------------- | --------------------------- | --------------------------- |
| `type`                      | *Optional[Literal["file"]]* | :heavy_minus_sign:          | N/A                         |
| `file_id`                   | *str*                       | :heavy_check_mark:          | N/A                         |