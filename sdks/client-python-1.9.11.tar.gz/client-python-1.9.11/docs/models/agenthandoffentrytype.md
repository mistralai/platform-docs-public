# AgentHandoffEntryType


## Values

| Name            | Value           |
| --------------- | --------------- |
| `AGENT_HANDOFF` | agent.handoff   |