# GithubRepositoryInType

## Example Usage

```typescript
import { GithubRepositoryInType } from "@mistralai/mistralai/models/components";

let value: GithubRepositoryInType = "github";
```

## Values

```typescript
"github"
```