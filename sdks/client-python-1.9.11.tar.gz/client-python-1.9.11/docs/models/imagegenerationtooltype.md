# ImageGenerationToolType


## Values

| Name               | Value              |
| ------------------ | ------------------ |
| `IMAGE_GENERATION` | image_generation   |