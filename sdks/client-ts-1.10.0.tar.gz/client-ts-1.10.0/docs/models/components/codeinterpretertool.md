# CodeInterpreterTool

## Example Usage

```typescript
import { CodeInterpreterTool } from "@mistralai/mistralai/models/components";

let value: CodeInterpreterTool = {};
```

## Fields

| Field                                                                                    | Type                                                                                     | Required                                                                                 | Description                                                                              |
| ---------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| `type`                                                                                   | [components.CodeInterpreterToolType](../../models/components/codeinterpretertooltype.md) | :heavy_minus_sign:                                                                       | N/A                                                                                      |