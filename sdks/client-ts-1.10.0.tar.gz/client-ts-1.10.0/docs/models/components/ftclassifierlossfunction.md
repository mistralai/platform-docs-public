# FTClassifierLossFunction

## Example Usage

```typescript
import { FTClassifierLossFunction } from "@mistralai/mistralai/models/components";

let value: FTClassifierLossFunction = "single_class";
```

## Values

```typescript
"single_class" | "multi_class"
```