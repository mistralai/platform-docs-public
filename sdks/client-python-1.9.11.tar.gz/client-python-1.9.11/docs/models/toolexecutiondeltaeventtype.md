# ToolExecutionDeltaEventType


## Values

| Name                   | Value                  |
| ---------------------- | ---------------------- |
| `TOOL_EXECUTION_DELTA` | tool.execution.delta   |