# TrainingFile


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `file_id`          | *str*              | :heavy_check_mark: | N/A                |
| `weight`           | *Optional[float]*  | :heavy_minus_sign: | N/A                |