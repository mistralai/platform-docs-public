# ImageURLChunkType


## Values

| Name        | Value       |
| ----------- | ----------- |
| `IMAGE_URL` | image_url   |