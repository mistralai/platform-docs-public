# FileSignedURL


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `url`              | *str*              | :heavy_check_mark: | N/A                |