# DocumentURLChunkType

## Example Usage

```typescript
import { DocumentURLChunkType } from "@mistralai/mistralai/models/components";

let value: DocumentURLChunkType = "document_url";
```

## Values

```typescript
"document_url"
```