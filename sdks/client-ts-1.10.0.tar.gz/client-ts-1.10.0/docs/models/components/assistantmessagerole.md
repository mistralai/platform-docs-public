# AssistantMessageRole

## Example Usage

```typescript
import { AssistantMessageRole } from "@mistralai/mistralai/models/components";

let value: AssistantMessageRole = "assistant";
```

## Values

```typescript
"assistant"
```