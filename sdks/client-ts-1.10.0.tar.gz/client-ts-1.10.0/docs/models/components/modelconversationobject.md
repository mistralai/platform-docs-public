# ModelConversationObject

## Example Usage

```typescript
import { ModelConversationObject } from "@mistralai/mistralai/models/components";

let value: ModelConversationObject = "conversation";
```

## Values

```typescript
"conversation"
```