# ClassifierDetailedJobOutObject

## Example Usage

```typescript
import { ClassifierDetailedJobOutObject } from "@mistralai/mistralai/models/components";

let value: ClassifierDetailedJobOutObject = "job";
```

## Values

```typescript
"job"
```