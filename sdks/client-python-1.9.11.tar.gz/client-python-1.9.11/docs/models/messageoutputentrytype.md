# MessageOutputEntryType


## Values

| Name             | Value            |
| ---------------- | ---------------- |
| `MESSAGE_OUTPUT` | message.output   |