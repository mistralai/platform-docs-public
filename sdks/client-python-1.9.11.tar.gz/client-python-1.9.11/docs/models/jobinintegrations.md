# JobInIntegrations


## Supported Types

### `models.WandbIntegration`

```python
value: models.WandbIntegration = /* values here */
```

