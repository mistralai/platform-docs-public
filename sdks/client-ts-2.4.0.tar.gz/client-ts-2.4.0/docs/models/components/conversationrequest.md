# ConversationRequest

## Example Usage

```typescript
import { ConversationRequest } from "@mistralai/mistralai/models/components";

let value: ConversationRequest = {
  inputs: [
    {
      name: "web_search_premium",
      arguments: "<value>",
    },
  ],
  completionArgs: {
    responseFormat: {
      type: "text",
    },
  },
};
```

## Fields

| Field                                                                                                            | Type                                                                                                             | Required                                                                                                         | Description                                                                                                      |
| ---------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| `inputs`                                                                                                         | *components.ConversationInputs*                                                                                  | :heavy_check_mark:                                                                                               | N/A                                                                                                              |
| `stream`                                                                                                         | *false*                                                                                                          | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `store`                                                                                                          | *boolean*                                                                                                        | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `handoffExecution`                                                                                               | [components.ConversationRequestHandoffExecution](../../models/components/conversationrequesthandoffexecution.md) | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `instructions`                                                                                                   | *string*                                                                                                         | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `tools`                                                                                                          | *components.ConversationRequestTool*[]                                                                           | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `completionArgs`                                                                                                 | [components.CompletionArgs](../../models/components/completionargs.md)                                           | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `guardrails`                                                                                                     | [components.GuardrailConfig](../../models/components/guardrailconfig.md)[]                                       | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `name`                                                                                                           | *string*                                                                                                         | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `description`                                                                                                    | *string*                                                                                                         | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `metadata`                                                                                                       | Record<string, *any*>                                                                                            | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `agentId`                                                                                                        | *string*                                                                                                         | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `agentVersion`                                                                                                   | *components.ConversationRequestAgentVersion*                                                                     | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |
| `model`                                                                                                          | *string*                                                                                                         | :heavy_minus_sign:                                                                                               | N/A                                                                                                              |