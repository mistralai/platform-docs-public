# UnarchiveFTModelOutObject


## Values

| Name    | Value   |
| ------- | ------- |
| `MODEL` | model   |