# Inputs

Chat to classify


## Supported Types

### `models.InstructRequestInputs`

```python
value: models.InstructRequestInputs = /* values here */
```

### `List[models.InstructRequest]`

```python
value: List[models.InstructRequest] = /* values here */
```

