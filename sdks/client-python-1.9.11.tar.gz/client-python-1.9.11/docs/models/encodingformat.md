# EncodingFormat


## Values

| Name     | Value    |
| -------- | -------- |
| `FLOAT`  | float    |
| `BASE64` | base64   |