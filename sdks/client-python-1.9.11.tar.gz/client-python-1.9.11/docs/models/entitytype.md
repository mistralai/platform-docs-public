# EntityType

The type of entity, used to share a library.


## Values

| Name        | Value       |
| ----------- | ----------- |
| `USER`      | User        |
| `WORKSPACE` | Workspace   |
| `ORG`       | Org         |