# ToolExecutionEntryType


## Values

| Name             | Value            |
| ---------------- | ---------------- |
| `TOOL_EXECUTION` | tool.execution   |