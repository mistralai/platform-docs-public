# AgentsApiV1AgentsListRequest

## Example Usage

```typescript
import { AgentsApiV1AgentsListRequest } from "@mistralai/mistralai/models/operations";

let value: AgentsApiV1AgentsListRequest = {};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `page`             | *number*           | :heavy_minus_sign: | N/A                |
| `pageSize`         | *number*           | :heavy_minus_sign: | N/A                |