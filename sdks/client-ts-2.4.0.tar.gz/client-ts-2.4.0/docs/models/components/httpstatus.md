# HTTPStatus

HTTP status codes and reason phrases

Status codes from the following RFCs are all observed:

    * RFC 7231: Hypertext Transfer Protocol (HTTP/1.1), obsoletes 2616
    * RFC 6585: Additional HTTP Status Codes
    * RFC 3229: Delta encoding in HTTP
    * RFC 4918: HTTP Extensions for WebDAV, obsoletes 2518
    * RFC 5842: Binding Extensions to WebDAV
    * RFC 7238: Permanent Redirect
    * RFC 2295: Transparent Content Negotiation in HTTP
    * RFC 2774: An HTTP Extension Framework
    * RFC 7725: An HTTP Status Code to Report Legal Obstacles
    * RFC 7540: Hypertext Transfer Protocol Version 2 (HTTP/2)
    * RFC 2324: Hyper Text Coffee Pot Control Protocol (HTCPCP/1.0)
    * RFC 8297: An HTTP Status Code for Indicating Hints
    * RFC 8470: Using Early Data in HTTP

## Example Usage

```typescript
import { HTTPStatus } from "@mistralai/mistralai/models/components";

let value: HTTPStatus = 413;

// Open enum: unrecognized values are captured as Unrecognized<number>
```

## Values

```typescript
100 | 101 | 102 | 103 | 200 | 201 | 202 | 203 | 204 | 205 | 206 | 207 | 208 | 226 | 300 | 301 | 302 | 303 | 304 | 305 | 307 | 308 | 400 | 401 | 402 | 403 | 404 | 405 | 406 | 407 | 408 | 409 | 410 | 411 | 412 | 413 | 414 | 415 | 416 | 417 | 418 | 421 | 422 | 423 | 424 | 425 | 426 | 428 | 429 | 431 | 451 | 500 | 501 | 502 | 503 | 504 | 505 | 506 | 507 | 508 | 510 | 511 | Unrecognized<number>
```