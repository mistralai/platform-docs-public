# CompletionJobOutObject

The object type of the fine-tuning job.


## Values

| Name  | Value |
| ----- | ----- |
| `JOB` | job   |