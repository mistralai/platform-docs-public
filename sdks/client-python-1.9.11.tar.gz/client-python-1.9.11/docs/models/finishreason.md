# FinishReason


## Values

| Name           | Value          |
| -------------- | -------------- |
| `STOP`         | stop           |
| `LENGTH`       | length         |
| `MODEL_LENGTH` | model_length   |
| `ERROR`        | error          |
| `TOOL_CALLS`   | tool_calls     |