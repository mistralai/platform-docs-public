# JobsOutObject


## Values

| Name   | Value  |
| ------ | ------ |
| `LIST` | list   |