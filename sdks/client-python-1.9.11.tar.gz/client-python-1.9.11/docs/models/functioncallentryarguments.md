# FunctionCallEntryArguments


## Supported Types

### `Dict[str, Any]`

```python
value: Dict[str, Any] = /* values here */
```

### `str`

```python
value: str = /* values here */
```

