# ChatModerationRequest


## Fields

| Field                                                                          | Type                                                                           | Required                                                                       | Description                                                                    |
| ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| `inputs`                                                                       | [models.ChatModerationRequestInputs](../models/chatmoderationrequestinputs.md) | :heavy_check_mark:                                                             | Chat to classify                                                               |
| `model`                                                                        | *str*                                                                          | :heavy_check_mark:                                                             | N/A                                                                            |