# FilesApiRoutesDeleteFileRequest

## Example Usage

```typescript
import { FilesApiRoutesDeleteFileRequest } from "@mistralai/mistralai/models/operations";

let value: FilesApiRoutesDeleteFileRequest = {
  fileId: "4bb1d830-8b98-4abe-bfae-a8719d615c18",
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `fileId`           | *string*           | :heavy_check_mark: | N/A                |