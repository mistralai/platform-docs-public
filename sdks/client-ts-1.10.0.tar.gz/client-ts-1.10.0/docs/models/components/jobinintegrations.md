# JobInIntegrations


## Supported Types

### `components.WandbIntegration`

```typescript
const value: components.WandbIntegration = {
  project: "<value>",
  apiKey: "<value>",
};
```

