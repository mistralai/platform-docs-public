# AgentsAPIV1AgentsListRequest


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `page`             | *Optional[int]*    | :heavy_minus_sign: | N/A                |
| `page_size`        | *Optional[int]*    | :heavy_minus_sign: | N/A                |