# Loc


## Supported Types

### `str`

```python
value: str = /* values here */
```

### `int`

```python
value: int = /* values here */
```

