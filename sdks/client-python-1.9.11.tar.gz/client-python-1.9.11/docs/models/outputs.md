# Outputs


## Supported Types

### `models.MessageOutputEntry`

```python
value: models.MessageOutputEntry = /* values here */
```

### `models.ToolExecutionEntry`

```python
value: models.ToolExecutionEntry = /* values here */
```

### `models.FunctionCallEntry`

```python
value: models.FunctionCallEntry = /* values here */
```

### `models.AgentHandoffEntry`

```python
value: models.AgentHandoffEntry = /* values here */
```

