# JobsAPIRoutesFineTuningGetFineTuningJobResponse

OK


## Supported Types

### `models.ClassifierDetailedJobOut`

```python
value: models.ClassifierDetailedJobOut = /* values here */
```

### `models.CompletionDetailedJobOut`

```python
value: models.CompletionDetailedJobOut = /* values here */
```

