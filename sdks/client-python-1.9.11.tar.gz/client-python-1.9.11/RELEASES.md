

## 2024-08-07 14:25:13
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.356.0 (2.388.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.0.0] .
### Releases
- [PyPI v1.0.0] https://pypi.org/project/mistralai/1.0.0 - .

## 2024-08-08 18:12:16
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.357.4 (2.390.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.0.1] .
### Releases
- [PyPI v1.0.1] https://pypi.org/project/mistralai/1.0.1 - .

## 2024-08-20 08:36:28
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.376.0 (2.402.5) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.0.2] .
### Releases
- [PyPI v1.0.2] https://pypi.org/project/mistralai/1.0.2 - .

## 2024-08-29 09:09:05
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.382.0 (2.404.11) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.0.3] .
### Releases
- [PyPI v1.0.3] https://pypi.org/project/mistralai/1.0.3 - .

## 2024-09-13 16:21:24
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.396.7 (2.415.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.1.0] .
### Releases
- [PyPI v1.1.0] https://pypi.org/project/mistralai/1.1.0 - .

## 2024-11-07 19:52:56
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.434.3 (2.452.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.2.0] .
### Releases
- [PyPI v1.2.0] https://pypi.org/project/mistralai/1.2.0 - .

## 2024-11-08 13:41:24
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.434.7 (2.452.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.2.1] .
### Releases
- [PyPI v1.2.1] https://pypi.org/project/mistralai/1.2.1 - .

## 2024-11-12 18:04:16
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.438.1 (2.457.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.2.2] .
### Releases
- [PyPI v1.2.2] https://pypi.org/project/mistralai/1.2.2 - .

## 2024-11-15 18:37:23
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.440.1 (2.460.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.2.3] .
### Releases
- [PyPI v1.2.3] https://pypi.org/project/mistralai/1.2.3 - .

## 2024-12-02 14:25:56
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.440.1 (2.460.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.2.4] .
### Releases
- [PyPI v1.2.4] https://pypi.org/project/mistralai/1.2.4 - .

## 2024-12-04 15:14:08
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.451.1 (2.470.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.2.5] .
### Releases
- [PyPI v1.2.5] https://pypi.org/project/mistralai/1.2.5 - .

## 2025-01-06 09:57:47
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.462.2 (2.486.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.2.6] .
### Releases
- [PyPI v1.2.6] https://pypi.org/project/mistralai/1.2.6 - .

## 2025-01-14 09:35:05
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.468.5 (2.493.11) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.3.0] .
### Releases
- [PyPI v1.3.0] https://pypi.org/project/mistralai/1.3.0 - .

## 2025-01-15 10:44:07
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.462.2 (2.486.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.3.1] .
### Releases
- [PyPI v1.3.1] https://pypi.org/project/mistralai/1.3.1 - .

## 2025-01-21 11:09:53
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.469.11 (2.493.32) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.4.0] .
### Releases
- [PyPI v1.4.0] https://pypi.org/project/mistralai/1.4.0 - .

## 2025-01-27 13:57:39
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.476.2 (2.495.1) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.5.0] .
### Releases
- [PyPI v1.5.0] https://pypi.org/project/mistralai/1.5.0 - .

## 2025-03-06 16:38:57
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.477.0 (2.497.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.5.1] .
### Releases
- [PyPI v1.5.1] https://pypi.org/project/mistralai/1.5.1 - .

## 2025-03-19 18:09:29
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.477.0 (2.497.0) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.5.2] .
### Releases
- [PyPI v1.5.2] https://pypi.org/project/mistralai/1.5.2 - .

## 2025-03-20 10:34:02
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.6.0] .
### Releases
- [PyPI v1.6.0] https://pypi.org/project/mistralai/1.6.0 - .

## 2025-04-16 18:35:19
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.7.0] .
### Releases
- [PyPI v1.7.0] https://pypi.org/project/mistralai/1.7.0 - .

## 2025-05-22 15:03:08
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.7.1] .
### Releases
- [PyPI v1.7.1] https://pypi.org/project/mistralai/1.7.1 - .

## 2025-05-26 11:05:08
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.8.0] .
### Releases
- [PyPI v1.8.0] https://pypi.org/project/mistralai/1.8.0 - .

## 2025-05-28 15:38:22
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.8.1] .
### Releases
- [PyPI v1.8.1] https://pypi.org/project/mistralai/1.8.1 - .

## 2025-06-10 16:42:28
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.517.3 (2.548.6) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.8.2] .
### Releases
- [PyPI v1.8.2] https://pypi.org/project/mistralai/1.8.2 - .

## 2025-06-30 17:56:20
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.1] .
### Releases
- [PyPI v1.9.1] https://pypi.org/project/mistralai/1.9.1 - .

## 2025-07-10 12:22:52
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.2] .
### Releases
- [PyPI v1.9.2] https://pypi.org/project/mistralai/1.9.2 - .

## 2025-07-23 17:06:32
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.3] .
### Releases
- [PyPI v1.9.3] https://pypi.org/project/mistralai/1.9.3 - .

## 2025-08-13 07:21:11
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.6] .
### Releases
- [PyPI v1.9.6] https://pypi.org/project/mistralai/1.9.6 - .

## 2025-08-20 08:28:00
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.7] .
### Releases
- [PyPI v1.9.7] https://pypi.org/project/mistralai/1.9.7 - .

## 2025-08-25 14:54:06
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.8] .
### Releases
- [PyPI v1.9.8] https://pypi.org/project/mistralai/1.9.8 - .

## 2025-08-26 17:34:05
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.9] .
### Releases
- [PyPI v1.9.9] https://pypi.org/project/mistralai/1.9.9 - .

## 2025-09-02 07:02:26
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.568.2 (2.634.2) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.10] .
### Releases
- [PyPI v1.9.10] https://pypi.org/project/mistralai/1.9.10 - .

## 2025-10-02 15:48:02
### Changes
Based on:
- OpenAPI Doc  
- Speakeasy CLI 1.606.10 (2.687.13) https://github.com/speakeasy-api/speakeasy
### Generated
- [python v1.9.11] .
### Releases
- [PyPI v1.9.11] https://pypi.org/project/mistralai/1.9.11 - .