# JobsAPIRoutesFineTuningCreateFineTuningJobResponse

OK


## Supported Types

### `models.Response1`

```python
value: models.Response1 = /* values here */
```

### `models.LegacyJobMetadataOut`

```python
value: models.LegacyJobMetadataOut = /* values here */
```

