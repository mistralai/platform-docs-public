# CompletionDetailedJobOutJobType


## Values

| Name         | Value        |
| ------------ | ------------ |
| `COMPLETION` | completion   |