# ThinkChunkType

## Example Usage

```typescript
import { ThinkChunkType } from "@mistralai/mistralai/models/components";

let value: ThinkChunkType = "thinking";
```

## Values

```typescript
"thinking"
```